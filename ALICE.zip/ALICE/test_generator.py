import numpy as np
import io
import sys

def test_generator():
    """
    测试生成器函数
    """
    # 准备测试数据
    test_input = """1 5
-0.04 -0.75 0.3 0.36 -0.07
0.5 -0.14 0.65 1.52 -0.23"""
    
    expected_output = "0.46 -0.89 0.95 1.88 -0.30"
    
    # 重定向输入
    sys.stdin = io.StringIO(test_input)
    
    # 重定向输出以捕获结果
    captured_output = io.StringIO()
    sys.stdout = captured_output
    
    # 导入并运行生成器
    from generator_gan import simple_generator
    simple_generator()
    
    # 恢复标准输入输出
    sys.stdin = sys.__stdin__
    sys.stdout = sys.__stdout__
    
    # 获取输出结果
    result = captured_output.getvalue().strip()
    
    print(f"输入数据:")
    print(test_input)
    print(f"\n实际输出: {result}")
    print(f"期望输出: {expected_output}")
    print(f"测试结果: {'通过' if result == expected_output else '失败'}")
    
    # 手动验证计算
    print("\n手动验证:")
    noise = np.array([[-0.04, -0.75, 0.3, 0.36, -0.07]])
    real = np.array([[0.5, -0.14, 0.65, 1.52, -0.23]])
    fake = real + noise
    print(f"噪声数据: {noise[0]}")
    print(f"真实数据: {real[0]}")
    print(f"假数据: {fake[0]}")
    print(f"格式化后: {' '.join([f'{x:.2f}' for x in fake[0]])}")

if __name__ == "__main__":
    test_generator() 