#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <cstring>

using namespace std;

class PokerWeightCalculator {
private:
    map<string, int> cardToValue;
    vector<int> cardCounts;
    bool hasJ1, hasJ2;
    int memo[1 << 18][2][2]; // 记忆化搜索
    
    void initCardMapping() {
        string values[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        for (int i = 0; i < 13; i++) {
            cardToValue[values[i]] = i;
        }
    }
    
    void parseCards(vector<string>& cards) {
        cardCounts.assign(13, 0);
        hasJ1 = hasJ2 = false;
        memset(memo, -1, sizeof(memo));
        
        for (string& card : cards) {
            if (card == "J1") {
                hasJ1 = true;
            } else if (card == "J2") {
                hasJ2 = true;
            } else {
                string value;
                if (card.length() == 3 && card.substr(1, 2) == "10") {
                    value = "10";
                } else {
                    value = card.substr(1);
                }
                cardCounts[cardToValue[value]]++;
            }
        }
    }
    
    bool canFormStraight(int start, const vector<int>& counts) {
        if (start > 8) return false;
        for (int i = start; i < start + 5; i++) {
            if (counts[i] == 0) return false;
        }
        return true;
    }
    
    int encodeState(const vector<int>& counts) {
        int state = 0;
        for (int i = 0; i < 13; i++) {
            state = state * 5 + min(counts[i], 4); // 最多4张相同的牌
        }
        return state;
    }
    
    int calculateMaxWeight(vector<int> counts, bool j1, bool j2) {
        // 简化版本，不使用记忆化
        int maxWeight = 0;
        
        // 尝试双王
        if (j1 && j2) {
            maxWeight = max(maxWeight, 5 + calculateMaxWeight(counts, false, false));
        }
        
        // 尝试四张
        for (int i = 0; i < 13; i++) {
            if (counts[i] >= 4) {
                vector<int> newCounts = counts;
                newCounts[i] -= 4;
                maxWeight = max(maxWeight, 5 + calculateMaxWeight(newCounts, j1, j2));
            }
        }
        
        // 尝试三张
        for (int i = 0; i < 13; i++) {
            if (counts[i] >= 3) {
                vector<int> newCounts = counts;
                newCounts[i] -= 3;
                maxWeight = max(maxWeight, 4 + calculateMaxWeight(newCounts, j1, j2));
            }
        }
        
        // 尝试单顺
        for (int start = 0; start <= 8; start++) {
            if (canFormStraight(start, counts)) {
                vector<int> newCounts = counts;
                for (int i = start; i < start + 5; i++) {
                    newCounts[i]--;
                }
                maxWeight = max(maxWeight, 3 + calculateMaxWeight(newCounts, j1, j2));
            }
        }
        
        // 尝试对牌
        for (int i = 0; i < 13; i++) {
            if (counts[i] >= 2) {
                vector<int> newCounts = counts;
                newCounts[i] -= 2;
                maxWeight = max(maxWeight, 2 + calculateMaxWeight(newCounts, j1, j2));
            }
        }
        
        return maxWeight;
    }
    
public:
    PokerWeightCalculator() {
        initCardMapping();
    }
    
    int solve(vector<string>& cards) {
        parseCards(cards);
        return calculateMaxWeight(cardCounts, hasJ1, hasJ2);
    }
};

int main() {
    int n;
    cin >> n;
    
    vector<string> cards(n);
    for (int i = 0; i < n; i++) {
        cin >> cards[i];
    }
    
    PokerWeightCalculator calculator;
    cout << calculator.solve(cards) << endl;
    
    return 0;
} 