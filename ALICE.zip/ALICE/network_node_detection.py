import math

def min_test_packets(numbers, minutes_to_transmit, minutes_to_test):
    """
    计算在规定时间内找出异常节点需要发送数据包的最少次数
    
    策略：
    1. 如果只有1个节点，不需要测试
    2. 如果只能进行1轮测试，使用二进制编码策略
    3. 如果能进行多轮测试，使用二分查找策略
    
    Args:
        numbers: 网络节点总数
        minutes_to_transmit: 每次数据包传输等待时间
        minutes_to_test: 总测试时间限制
    
    Returns:
        最少测试数据包数量
    """
    # 特殊情况：只有1个节点，不需要测试
    if numbers == 1:
        return 0
    
    # 计算最多能进行多少轮测试
    max_rounds = minutes_to_test // minutes_to_transmit
    
    # 如果时间不够进行一轮测试，返回-1表示无法完成
    if max_rounds == 0:
        return -1
    
    # 计算二分查找需要的轮数
    binary_search_rounds = math.ceil(math.log2(numbers))
    
    # 如果能进行足够的轮数，使用二分查找（每轮1个数据包）
    if max_rounds >= binary_search_rounds:
        return binary_search_rounds
    
    # 如果只能进行1轮测试，使用二进制编码策略
    if max_rounds == 1:
        # 需要的数据包数量是 ceil(log2(numbers))
        # 这是因为我们可以用二进制编码来表示每个节点
        return math.ceil(math.log2(numbers))
    
    # 对于其他情况，暂时返回-1（需要更复杂的策略）
    return -1

def solve():
    """ACM模式的主函数"""
    # 读取输入
    numbers = int(input().strip())
    minutes_to_transmit = int(input().strip())
    minutes_to_test = int(input().strip())
    
    # 计算结果
    result = min_test_packets(numbers, minutes_to_transmit, minutes_to_test)
    
    # 输出结果
    print(result)

if __name__ == "__main__":
    solve()
