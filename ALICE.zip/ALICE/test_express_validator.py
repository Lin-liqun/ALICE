from express_validator import validate_and_fix_express_number

def test_express_validator():
    """测试快递单号校验功能"""
    
    # 测试用例1：示例中的情况 - AB123456C 应该修复为 AB123456Y
    test1 = "AB123456C"
    result1 = validate_and_fix_express_number(test1)
    print(f"测试1: {test1} -> {result1}")
    
    # 验证计算过程
    prefix = "AB123456"
    ascii_sum = sum(ord(char) for char in prefix)
    print(f"ASCII码之和: {ascii_sum}")
    print(f"440 % 26 = {ascii_sum % 26}")
    print(f"24 + 65 = {ascii_sum % 26 + ord('A')}")
    print(f"对应字符: {chr((ascii_sum % 26) + ord('A'))}")
    print()
    
    # 测试用例2：正确的单号
    test2 = "AB123456Y"
    result2 = validate_and_fix_express_number(test2)
    print(f"测试2: {test2} -> {result2}")
    
    # 测试用例3：长度不对
    test3 = "AB12345"
    result3 = validate_and_fix_express_number(test3)
    print(f"测试3: {test3} -> {result3}")
    
    # 测试用例4：前两位不是大写字母
    test4 = "ab123456C"
    result4 = validate_and_fix_express_number(test4)
    print(f"测试4: {test4} -> {result4}")
    
    # 测试用例5：中间不是数字
    test5 = "AB12a456C"
    result5 = validate_and_fix_express_number(test5)
    print(f"测试5: {test5} -> {result5}")
    
    # 测试用例6：另一个需要修复的例子
    test6 = "CD789012A"
    result6 = validate_and_fix_express_number(test6)
    print(f"测试6: {test6} -> {result6}")
    
    # 验证测试6的计算
    prefix6 = "CD789012"
    ascii_sum6 = sum(ord(char) for char in prefix6)
    correct_check6 = chr((ascii_sum6 % 26) + ord('A'))
    print(f"测试6计算: ASCII和={ascii_sum6}, 校验位={correct_check6}")


if __name__ == "__main__":
    test_express_validator() 