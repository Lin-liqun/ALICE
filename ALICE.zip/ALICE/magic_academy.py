def solve_magic_academy(n, m, M, power, mana, bonus):
    """
    解决魔法学院课程学习问题
    
    Args:
        n: 课程数量
        m: 楼层数量
        M: 初始法力值
        power: 每门课程的魔法强度
        mana: 每门课程的法力消耗
        bonus: 每层楼的加成系数
    
    Returns:
        int: 最大魔法强度总和
    """
    # dp[i][j][k] 表示考虑前i门课程，最后一门学习的课程在第j层，总消耗k法力的最大强度
    # 使用m表示还没开始学习任何课程的状态
    # dp[j][k] 表示最后在第j层，消耗k法力的最大强度
    
    # 初始化DP数组
    prev_dp = {}  # 使用字典优化空间，只存储可达状态
    curr_dp = {}
    
    # 初始状态：还没学任何课程
    prev_dp[(m, 0)] = 0  # (楼层, 法力消耗) -> 最大强度
    
    max_strength = 0
    
    # 逐个考虑每门课程
    for i in range(n):
        curr_dp = {}
        
        # 对于每个之前的状态
        for (prev_floor, prev_mana), prev_strength in prev_dp.items():
            # 选择1：不学习当前课程（跳过）
            # 注意：由于必须按顺序学习，跳过当前课程意味着后续课程也不能学习
            max_strength = max(max_strength, prev_strength)
            
            # 选择2：学习当前课程，尝试每个楼层
            for curr_floor in range(m):
                # 计算在当前楼层学习的消耗和收益
                course_mana = mana[i] * bonus[curr_floor]
                course_power = power[i] * bonus[curr_floor]
                
                # 计算切换楼层的额外消耗
                switch_cost = 0
                if prev_floor < m:  # 如果之前已经在某个楼层
                    if curr_floor > prev_floor:  # 从低层到高层
                        switch_cost = curr_floor - prev_floor
                # 如果prev_floor == m，说明是初始状态，无切换成本
                
                # 总消耗
                total_mana = prev_mana + course_mana + switch_cost
                
                # 检查是否超出法力限制
                if total_mana <= M:
                    new_strength = prev_strength + course_power
                    key = (curr_floor, total_mana)
                    
                    if key not in curr_dp or curr_dp[key] < new_strength:
                        curr_dp[key] = new_strength
                        max_strength = max(max_strength, new_strength)
        
        # 更新DP状态
        prev_dp = curr_dp
    
    return max_strength


def main():
    """ACM模式主函数"""
    # 读取输入
    n, m, M = map(int, input().strip().split())
    power = list(map(int, input().strip().split()))
    mana = list(map(int, input().strip().split()))
    bonus = list(map(int, input().strip().split()))
    
    # 解决问题并输出结果
    result = solve_magic_academy(n, m, M, power, mana, bonus)
    print(result)


if __name__ == "__main__":
    main() 