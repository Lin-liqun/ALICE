from christmas_tree_lights import solve_christmas_tree_lights

# 测试示例1
n = 5
initial = [1, 2, 3, 0, 1]
target = [2, 3, 1, 0, 2]

result = solve_christmas_tree_lights(n, initial, target)
print(f"示例1结果: {result} (期望: 3)")

# 测试简单情况
n2 = 3
initial2 = [1, 2, 3]
target2 = [2, 3, 4]
result2 = solve_christmas_tree_lights(n2, initial2, target2)
print(f"简单测试结果: {result2} (期望: 1)")

# 测试边界情况
n3 = 1
initial3 = [1]
target3 = [3]
result3 = solve_christmas_tree_lights(n3, initial3, target3)
print(f"单节点测试: {result3} (期望: 2)") 