#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

// 检查给定的玩手机情况和说谎情况是否一致
bool isConsistent(vector<bool>& playPhone, vector<bool>& isLiar) {
    // a的话：我可没玩手机 (a没玩手机)
    bool aStatement = !playPhone[0];  // a说自己没玩手机
    if (isLiar[0] == aStatement) {  // 如果a说谎，他的话应该是假的；如果不说谎，话应该是真的
        return false;
    }
    
    // b的话：c玩手机了
    bool bStatement = playPhone[2];  // b说c玩手机
    if (isLiar[1] == bStatement) {  // 如果b说谎，他的话应该是假的；如果不说谎，话应该是真的
        return false;
    }
    
    // c的话：玩手机的肯定是d (只有d玩手机)
    bool cStatement = playPhone[3] && !playPhone[0] && !playPhone[1] && !playPhone[2];  // 只有d玩手机
    if (isLiar[2] == cStatement) {  // 如果c说谎，他的话应该是假的；如果不说谎，话应该是真的
        return false;
    }
    
    // d的话：c胡说 (c说的是假话)
    bool dStatement = isLiar[2];  // d说c说假话
    if (isLiar[3] == dStatement) {  // 如果d说谎，他的话应该是假的；如果不说谎，话应该是真的
        return false;
    }
    
    return true;
}

vector<string> solve(int x) {
    vector<string> result;
    vector<string> names = {"a", "b", "c", "d"};
    
    // 枚举所有可能的玩手机组合 (2^4 = 16种)
    for (int phoneMask = 0; phoneMask < 16; phoneMask++) {
        vector<bool> playPhone(4);
        for (int i = 0; i < 4; i++) {
            playPhone[i] = (phoneMask >> i) & 1;
        }
        
        // 枚举所有可能的说谎组合 (2^4 = 16种)
        for (int liarMask = 0; liarMask < 16; liarMask++) {
            vector<bool> isLiar(4);
            int liarCount = 0;
            for (int i = 0; i < 4; i++) {
                isLiar[i] = (liarMask >> i) & 1;
                if (isLiar[i]) liarCount++;
            }
            
            // 如果说谎人数不等于x，跳过
            if (liarCount != x) continue;
            
            // 检查逻辑一致性
            if (isConsistent(playPhone, isLiar)) {
                // 找到一致的情况，收集玩手机的学生
                vector<string> current;
                for (int i = 0; i < 4; i++) {
                    if (playPhone[i]) {
                        current.push_back(names[i]);
                    }
                }
                
                // 如果是第一个解或者与之前的解相同，保存
                if (result.empty()) {
                    result = current;
                } else if (result != current) {
                    // 如果有多个不同的解，说明无解
                    return {};
                }
            }
        }
    }
    
    return result;
}

int main() {
    int x;
    cin >> x;
    
    vector<string> result = solve(x);
    
    if (result.empty()) {
        cout << "[]" << endl;
    } else {
        cout << "[";
        for (int i = 0; i < result.size(); i++) {
            if (i > 0) cout << ", ";
            cout << "\"" << result[i] << "\"";
        }
        cout << "]" << endl;
    }
    
    return 0;
} 