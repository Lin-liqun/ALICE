import cv2
import numpy as np
import torch
import torchvision.transforms.functional as TF
from PIL import Image
import time
import threading
from queue import Queue
import sys
import os

# 添加项目路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class JetsonALICEInference:
    """Jetson Nano上的ALICE模型推理类"""
    
    def __init__(self, model_path, device='cuda', input_size=(256, 256)):
        self.device = device if torch.cuda.is_available() else 'cpu'
        self.input_size = input_size
        self.model = self._load_model(model_path)
        self.frame_queue = Queue(maxsize=2)
        print(f"ALICE推理器初始化完成，使用设备: {self.device}")
        
    def _load_model(self, model_path):
        """加载优化后的模型"""
        try:
            from model.ALICC import ALICC
            
            model = ALICC(Ch_img=3, Channels=32, state='Test', REF=True, tests=False)
            checkpoint = torch.load(model_path, map_location=self.device)
            
            # 处理不同的checkpoint格式
            if 'model' in checkpoint:
                model.load_state_dict(checkpoint['model'])
            else:
                model.load_state_dict(checkpoint)
                
            model.to(self.device)
            model.eval()
            
            # 预热模型
            print("正在预热模型...")
            dummy_color = torch.randn(1, 3, *self.input_size).to(self.device)
            dummy_mono = torch.randn(1, 3, *self.input_size).to(self.device)
            with torch.no_grad():
                _ = model(dummy_color, dummy_mono)
            print("模型预热完成")
            
            return model
            
        except Exception as e:
            print(f"模型加载失败: {e}")
            raise
    
    def preprocess_image(self, image):
        """图像预处理"""
        if isinstance(image, np.ndarray):
            # 确保图像是RGB格式
            if len(image.shape) == 3 and image.shape[2] == 3:
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image = Image.fromarray(image)
        
        # 保存原始尺寸
        original_size = image.size
        
        # 调整大小到模型输入尺寸
        image = image.resize(self.input_size, Image.BICUBIC)
        
        # 转换为张量并归一化
        tensor = TF.to_tensor(image).unsqueeze(0).to(self.device)
        
        return tensor, original_size
    
    def postprocess_output(self, output, original_size):
        """输出后处理"""
        # 调整回原始尺寸
        if original_size != self.input_size:
            output = TF.resize(output, original_size[::-1], interpolation=Image.BICUBIC)
        
        # 转换为numpy数组
        output = torch.clamp(output, 0, 1).squeeze(0).permute(1, 2, 0).cpu().numpy()
        output = (output * 255).astype(np.uint8)
        
        # 转换颜色空间回BGR
        output = cv2.cvtColor(output, cv2.COLOR_RGB2BGR)
        
        return output
    
    def clear_gpu_memory(self):
        """清理GPU内存"""
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    def inference_single(self, color_image, mono_image=None):
        """单张图像推理"""
        start_time = time.time()
        
        try:
            # 预处理彩色图像
            color_tensor, original_size = self.preprocess_image(color_image)
            
            # 处理单色图像
            if mono_image is None:
                # 如果没有单色图像，使用彩色图像的灰度版本
                if isinstance(color_image, np.ndarray):
                    gray = cv2.cvtColor(color_image, cv2.COLOR_BGR2GRAY)
                    mono_image = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
                else:
                    mono_image = color_image.convert('L').convert('RGB')
            
            mono_tensor, _ = self.preprocess_image(mono_image)
            
            # 推理
            with torch.no_grad():
                if self.device == 'cuda':
                    # 在GPU上推理时使用半精度以节省内存
                    if hasattr(self.model, 'half'):
                        color_tensor = color_tensor.half()
                        mono_tensor = mono_tensor.half()
                
                result = self.model(color_tensor, mono_tensor)
                
                # 处理不同的输出格式
                if isinstance(result, tuple):
                    restored_img = result[0]  # 只取主要输出
                else:
                    restored_img = result
            
            # 后处理
            final_result = self.postprocess_output(restored_img, original_size)
            
            inference_time = time.time() - start_time
            
            return final_result, inference_time
            
        except Exception as e:
            print(f"推理错误: {e}")
            return color_image, 0.0
        finally:
            # 清理GPU内存
            self.clear_gpu_memory()
    
    def inference_video_stream(self, color_cap, mono_cap=None, output_path=None, display=True):
        """视频流推理"""
        # 设置视频写入器
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*'XVID')
            fps = int(color_cap.get(cv2.CAP_PROP_FPS)) or 30
            width = int(color_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(color_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
            print(f"开始录制视频到: {output_path}")
        
        frame_count = 0
        total_time = 0
        fps_history = []
        
        print("开始视频流推理，按'q'键退出...")
        
        try:
            while True:
                # 读取彩色帧
                ret_color, color_frame = color_cap.read()
                if not ret_color:
                    print("无法读取彩色摄像头帧")
                    break
                
                # 读取单色帧（如果有）
                mono_frame = None
                if mono_cap:
                    ret_mono, mono_frame = mono_cap.read()
                    if not ret_mono:
                        print("无法读取单色摄像头帧")
                        mono_frame = None
                
                # 推理
                result, inference_time = self.inference_single(color_frame, mono_frame)
                
                frame_count += 1
                total_time += inference_time
                
                # 计算FPS
                current_fps = 1.0 / inference_time if inference_time > 0 else 0
                fps_history.append(current_fps)
                if len(fps_history) > 30:  # 保持最近30帧的FPS历史
                    fps_history.pop(0)
                avg_fps = sum(fps_history) / len(fps_history)
                
                # 在结果图像上添加信息
                info_text = f'FPS: {avg_fps:.1f} | Frame: {frame_count} | Time: {inference_time*1000:.1f}ms'
                cv2.putText(result, info_text, (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                
                # 显示结果
                if display:
                    # 调整显示窗口大小
                    display_height = 480
                    display_width = int(result.shape[1] * display_height / result.shape[0])
                    
                    result_display = cv2.resize(result, (display_width, display_height))
                    original_display = cv2.resize(color_frame, (display_width, display_height))
                    
                    cv2.imshow('ALICE Enhanced', result_display)
                    cv2.imshow('Original', original_display)
                
                # 保存视频帧
                if output_path:
                    out.write(result)
                
                # 检查退出条件
                if display and cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                
                # 每100帧打印一次统计信息
                if frame_count % 100 == 0:
                    print(f"已处理 {frame_count} 帧，平均FPS: {avg_fps:.2f}")
                
        except KeyboardInterrupt:
            print("\n推理被用户中断")
        
        except Exception as e:
            print(f"视频流推理错误: {e}")
        
        finally:
            # 清理资源
            color_cap.release()
            if mono_cap:
                mono_cap.release()
            if output_path and 'out' in locals():
                out.release()
            if display:
                cv2.destroyAllWindows()
            
            # 打印最终统计信息
            if frame_count > 0:
                avg_fps = frame_count / total_time if total_time > 0 else 0
                print(f"\n=== 推理统计 ===")
                print(f"总帧数: {frame_count}")
                print(f"总时间: {total_time:.2f}秒")
                print(f"平均FPS: {avg_fps:.2f}")
                print(f"平均推理时间: {total_time/frame_count*1000:.2f}ms")
    
    def benchmark(self, test_image_path=None, num_iterations=100):
        """性能基准测试"""
        print(f"开始性能基准测试 ({num_iterations} 次推理)...")
        
        # 准备测试图像
        if test_image_path and os.path.exists(test_image_path):
            test_image = cv2.imread(test_image_path)
        else:
            # 创建随机测试图像
            test_image = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        
        times = []
        
        # 预热
        for _ in range(10):
            _, _ = self.inference_single(test_image)
        
        # 基准测试
        for i in range(num_iterations):
            result, inf_time = self.inference_single(test_image)
            times.append(inf_time)
            
            if (i + 1) % 20 == 0:
                print(f"完成 {i + 1}/{num_iterations} 次推理")
        
        # 统计结果
        times = np.array(times)
        avg_time = np.mean(times)
        std_time = np.std(times)
        min_time = np.min(times)
        max_time = np.max(times)
        avg_fps = 1.0 / avg_time
        
        print(f"\n=== 基准测试结果 ===")
        print(f"平均推理时间: {avg_time*1000:.2f} ± {std_time*1000:.2f} ms")
        print(f"最快推理时间: {min_time*1000:.2f} ms")
        print(f"最慢推理时间: {max_time*1000:.2f} ms")
        print(f"平均FPS: {avg_fps:.2f}")
        print(f"输入尺寸: {self.input_size}")
        print(f"设备: {self.device}")
        
        return {
            'avg_time': avg_time,
            'std_time': std_time,
            'min_time': min_time,
            'max_time': max_time,
            'avg_fps': avg_fps,
            'times': times
        }

# 使用示例
if __name__ == "__main__":
    # 测试推理器
    model_path = "../checkpoints/Real/model_best.pth"
    
    if not os.path.exists(model_path):
        print(f"模型文件不存在: {model_path}")
        print("请确保模型文件路径正确")
        exit(1)
    
    # 初始化推理器
    try:
        inference = JetsonALICEInference(model_path)
        print("推理器初始化成功!")
        
        # 运行基准测试
        benchmark_results = inference.benchmark(num_iterations=50)
        
        # 测试实时推理（如果有摄像头）
        cap = cv2.VideoCapture(0)
        if cap.isOpened():
            print("检测到摄像头，开始实时推理测试...")
            print("按'q'键退出")
            inference.inference_video_stream(cap, display=True)
        else:
            print("未检测到摄像头，跳过实时推理测试")
            
    except Exception as e:
        print(f"测试失败: {e}")
        import traceback
        traceback.print_exc() 