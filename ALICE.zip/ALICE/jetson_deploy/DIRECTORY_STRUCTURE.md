# ALICE Jetson Nano 部署目录结构

部署完成后，项目的目录结构如下：

```
/home/$USER/ALICE/                          # 项目根目录
├── alice_env/                              # Python虚拟环境
│   ├── bin/
│   ├── lib/
│   └── ...
├── checkpoints/                            # 模型检查点目录
│   ├── Real/
│   │   └── model_best.pth                 # 真实数据预训练模型
│   └── Syn/
│       └── model_best.pth                 # 合成数据预训练模型
├── data/                                   # 数据目录
│   ├── test_images/                       # 测试图像
│   └── test_videos/                       # 测试视频
├── results/                                # 输出结果目录
│   ├── images/                            # 处理后的图像
│   ├── videos/                            # 处理后的视频
│   └── benchmarks/                        # 基准测试结果
├── jetson_deploy/                          # Jetson部署文件
│   ├── jetson_inference.py               # 推理引擎
│   ├── deploy_alice.py                    # 部署脚本
│   ├── install_alice_jetson.sh           # 安装脚本
│   ├── README.md                          # 部署说明
│   └── DIRECTORY_STRUCTURE.md             # 目录结构说明
├── model/                                  # 模型定义
│   ├── __init__.py
│   ├── ALICC.py                           # ALICE模型定义
│   └── ptflops/                           # 性能分析工具
├── utils/                                  # 工具函数
│   ├── __init__.py
│   ├── config.py                          # 配置管理
│   ├── dataset.py                         # 数据集处理
│   ├── image.py                           # 图像处理
│   └── netset.py                          # 网络工具
├── option/                                 # 配置文件
│   └── opt_train.yml                      # 训练配置
├── start_alice.sh                         # 主启动脚本
├── benchmark.sh                           # 基准测试脚本
├── camera_test.sh                         # 摄像头测试脚本
├── test.py                                # 原始测试脚本
├── JETSON_NANO_DEPLOYMENT_GUIDE.md       # 完整部署指南
└── README.md                              # 项目说明
```

## 桌面快捷方式

安装后会在桌面创建以下快捷方式：

```
~/Desktop/
├── ALICE_Camera.desktop                   # 摄像头推理快捷方式
└── ALICE_Benchmark.desktop                # 性能测试快捷方式
```

## 重要文件说明

### 核心文件
- `model/ALICC.py` - ALICE模型的核心实现
- `jetson_deploy/jetson_inference.py` - Jetson优化的推理引擎
- `jetson_deploy/deploy_alice.py` - 统一的部署接口

### 启动脚本
- `start_alice.sh` - 主启动脚本，支持所有模式
- `benchmark.sh` - 快速性能测试
- `camera_test.sh` - 快速摄像头测试

### 配置文件
- `option/opt_train.yml` - 训练时的配置参数
- `alice_env/` - 独立的Python环境，包含所有依赖

### 输出目录
- `results/images/` - 处理后的图像保存位置
- `results/videos/` - 处理后的视频保存位置
- `results/benchmarks/` - 性能测试结果

## 文件权限

确保以下文件具有执行权限：

```bash
chmod +x start_alice.sh
chmod +x benchmark.sh
chmod +x camera_test.sh
chmod +x jetson_deploy/install_alice_jetson.sh
chmod +x ~/Desktop/ALICE_*.desktop
```

## 环境变量

启动脚本会自动设置以下环境变量：

- `CUDA_VISIBLE_DEVICES=0` - 指定使用的GPU
- `PYTHONPATH` - 包含项目路径
- 虚拟环境激活

## 存储空间使用

预计占用存储空间：

- 基础安装: ~3GB
- PyTorch + 依赖: ~2GB  
- 模型文件: ~100MB
- 虚拟环境: ~1GB
- **总计: ~6-7GB**

建议至少预留10GB空闲空间用于结果输出和临时文件。 