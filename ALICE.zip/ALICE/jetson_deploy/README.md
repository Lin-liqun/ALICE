# ALICE Jetson Nano 部署包

这个目录包含了在NVIDIA Jetson Nano上部署ALICE模型的所有必要文件。

## 快速开始

### 1. 自动安装（推荐）

```bash
# 下载安装脚本并运行
chmod +x install_alice_jetson.sh
./install_alice_jetson.sh
```

### 2. 手动安装

如果自动安装遇到问题，请参考 `JETSON_NANO_DEPLOYMENT_GUIDE.md` 中的详细步骤。

## 文件说明

- `install_alice_jetson.sh` - 自动安装脚本
- `jetson_inference.py` - Jetson优化的推理引擎
- `deploy_alice.py` - 主部署脚本
- `JETSON_NANO_DEPLOYMENT_GUIDE.md` - 完整部署指南

## 使用方法

安装完成后，可以使用以下命令：

```bash
# 实时摄像头推理
./start_alice.sh --model checkpoints/Real/model_best.pth --mode camera

# 处理单张图像
./start_alice.sh --model checkpoints/Real/model_best.pth --mode image --input test.jpg

# 处理视频文件
./start_alice.sh --model checkpoints/Real/model_best.pth --mode video --input video.mp4

# 性能基准测试
./benchmark.sh
```

## 系统要求

- NVIDIA Jetson Nano Developer Kit
- JetPack 4.6.1+
- 4GB RAM (推荐增加交换文件)
- 64GB+ microSD卡
- USB/CSI摄像头

## 性能预期

- 输入尺寸 256x256: ~15-20 FPS
- 输入尺寸 480x640: ~8-12 FPS
- GPU内存使用: ~1.5GB
- 推理延迟: 50-80ms

## 故障排除

1. **内存不足**: 增加交换文件大小
2. **CUDA错误**: 检查JetPack版本和CUDA安装
3. **摄像头问题**: 确认摄像头连接和权限
4. **性能慢**: 启用最大性能模式

详细故障排除请参考完整部署指南。

## 支持

如有问题，请查看：
1. 完整部署指南中的故障排除部分
2. 项目主页的Issues页面
3. NVIDIA Jetson开发者论坛 