#!/usr/bin/env python3
"""
ALICE模型Jetson Nano部署脚本
支持图像、视频和实时摄像头推理
"""

import argparse
import cv2
import os
import sys
import time
import numpy as np
from pathlib import Path

# 添加项目路径
current_dir = Path(__file__).parent
project_root = current_dir.parent
sys.path.append(str(project_root))

try:
    from jetson_deploy.jetson_inference import JetsonALICEInference
except ImportError:
    print("错误: 无法导入JetsonALICEInference")
    print("请确保jetson_inference.py在正确的路径中")
    sys.exit(1)

def check_jetson_environment():
    """检查Jetson环境"""
    try:
        import torch
        print(f"PyTorch版本: {torch.__version__}")
        print(f"CUDA可用: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            print(f"CUDA版本: {torch.version.cuda}")
            print(f"GPU设备: {torch.cuda.get_device_name(0)}")
            print(f"GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
        return True
    except ImportError as e:
        print(f"环境检查失败: {e}")
        return False

def setup_camera(camera_id, width=640, height=480, fps=30):
    """设置摄像头"""
    cap = cv2.VideoCapture(camera_id)
    if not cap.isOpened():
        print(f"无法打开摄像头 {camera_id}")
        return None
    
    # 设置摄像头参数
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    
    # 验证设置
    actual_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    actual_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    actual_fps = cap.get(cv2.CAP_PROP_FPS)
    
    print(f"摄像头 {camera_id} 设置:")
    print(f"  分辨率: {actual_width}x{actual_height}")
    print(f"  帧率: {actual_fps:.1f} FPS")
    
    return cap

def process_single_image(inference_engine, input_path, output_path):
    """处理单张图像"""
    print(f"处理图像: {input_path}")
    
    # 读取图像
    if not os.path.exists(input_path):
        print(f"错误: 输入图像不存在: {input_path}")
        return False
    
    color_img = cv2.imread(input_path)
    if color_img is None:
        print(f"错误: 无法读取图像: {input_path}")
        return False
    
    print(f"输入图像尺寸: {color_img.shape}")
    
    # 推理
    start_time = time.time()
    result, inf_time = inference_engine.inference_single(color_img)
    total_time = time.time() - start_time
    
    # 保存结果
    if output_path is None:
        output_path = f"enhanced_{os.path.basename(input_path)}"
    
    success = cv2.imwrite(output_path, result)
    if success:
        print(f"结果已保存到: {output_path}")
        print(f"推理时间: {inf_time*1000:.2f}ms")
        print(f"总处理时间: {total_time*1000:.2f}ms")
        return True
    else:
        print(f"错误: 无法保存结果到: {output_path}")
        return False

def process_video_file(inference_engine, input_path, output_path):
    """处理视频文件"""
    print(f"处理视频: {input_path}")
    
    if not os.path.exists(input_path):
        print(f"错误: 输入视频不存在: {input_path}")
        return False
    
    cap = cv2.VideoCapture(input_path)
    if not cap.isOpened():
        print(f"错误: 无法打开视频: {input_path}")
        return False
    
    # 获取视频信息
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    print(f"输入视频信息:")
    print(f"  分辨率: {width}x{height}")
    print(f"  帧率: {fps:.1f} FPS")
    print(f"  总帧数: {total_frames}")
    
    if output_path is None:
        name, ext = os.path.splitext(input_path)
        output_path = f"{name}_enhanced{ext}"
    
    print(f"开始处理视频，输出到: {output_path}")
    
    # 使用推理引擎处理视频
    inference_engine.inference_video_stream(cap, output_path=output_path, display=False)
    
    return True

def process_camera_stream(inference_engine, color_camera_id, mono_camera_id=None, 
                         output_path=None, camera_width=640, camera_height=480):
    """处理摄像头流"""
    print("设置摄像头...")
    
    # 设置彩色摄像头
    color_cap = setup_camera(color_camera_id, camera_width, camera_height)
    if color_cap is None:
        return False
    
    # 设置单色摄像头（如果有）
    mono_cap = None
    if mono_camera_id is not None:
        mono_cap = setup_camera(mono_camera_id, camera_width, camera_height)
        if mono_cap is None:
            print(f"警告: 无法打开单色摄像头 {mono_camera_id}，将使用彩色摄像头的灰度版本")
    
    print("开始实时推理...")
    print("控制说明:")
    print("  按 'q' 键退出")
    print("  按 's' 键截图")
    print("  按 'r' 键开始/停止录制")
    
    # 开始推理
    inference_engine.inference_video_stream(
        color_cap, mono_cap, output_path=output_path, display=True)
    
    return True

def main():
    parser = argparse.ArgumentParser(
        description='ALICE模型Jetson Nano部署脚本',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 处理单张图像
  python deploy_alice.py --model model_best.pth --mode image --input test.jpg
  
  # 处理视频文件
  python deploy_alice.py --model model_best.pth --mode video --input video.mp4
  
  # 实时摄像头推理
  python deploy_alice.py --model model_best.pth --mode camera --color_camera 0
  
  # 双摄像头推理
  python deploy_alice.py --model model_best.pth --mode camera --color_camera 0 --mono_camera 1
        """)
    
    parser.add_argument('--model', type=str, required=True, 
                       help='模型权重文件路径')
    parser.add_argument('--mode', type=str, 
                       choices=['image', 'video', 'camera', 'benchmark'], 
                       default='camera', help='运行模式')
    parser.add_argument('--input', type=str, 
                       help='输入文件路径 (image/video模式)')
    parser.add_argument('--output', type=str, 
                       help='输出文件路径')
    parser.add_argument('--color_camera', type=int, default=0, 
                       help='彩色摄像头设备ID')
    parser.add_argument('--mono_camera', type=int, 
                       help='单色摄像头设备ID')
    parser.add_argument('--camera_width', type=int, default=640, 
                       help='摄像头宽度')
    parser.add_argument('--camera_height', type=int, default=480, 
                       help='摄像头高度')
    parser.add_argument('--input_size', type=int, nargs=2, default=[256, 256], 
                       help='模型输入尺寸 [height, width]')
    parser.add_argument('--device', type=str, default='cuda', 
                       choices=['cuda', 'cpu'], help='推理设备')
    parser.add_argument('--benchmark_iterations', type=int, default=100, 
                       help='基准测试迭代次数')
    
    args = parser.parse_args()
    
    # 检查环境
    print("=== ALICE Jetson Nano 部署 ===")
    if not check_jetson_environment():
        print("环境检查失败，退出")
        sys.exit(1)
    
    # 检查模型文件
    if not os.path.exists(args.model):
        print(f"错误: 模型文件不存在: {args.model}")
        sys.exit(1)
    
    # 初始化推理引擎
    print(f"\n正在加载ALICE模型: {args.model}")
    try:
        input_size = tuple(args.input_size)
        inference_engine = JetsonALICEInference(
            args.model, 
            device=args.device, 
            input_size=input_size
        )
        print("模型加载成功!\n")
    except Exception as e:
        print(f"模型加载失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # 根据模式执行不同操作
    success = False
    
    if args.mode == 'image':
        if not args.input:
            print("错误: image模式需要指定--input参数")
            sys.exit(1)
        success = process_single_image(inference_engine, args.input, args.output)
        
    elif args.mode == 'video':
        if not args.input:
            print("错误: video模式需要指定--input参数")
            sys.exit(1)
        success = process_video_file(inference_engine, args.input, args.output)
        
    elif args.mode == 'camera':
        success = process_camera_stream(
            inference_engine, 
            args.color_camera, 
            args.mono_camera,
            args.output,
            args.camera_width,
            args.camera_height
        )
        
    elif args.mode == 'benchmark':
        print("开始性能基准测试...")
        test_image_path = args.input if args.input else None
        benchmark_results = inference_engine.benchmark(
            test_image_path, 
            args.benchmark_iterations
        )
        success = True
        
        # 保存基准测试结果
        import json
        benchmark_file = f"benchmark_results_{int(time.time())}.json"
        with open(benchmark_file, 'w') as f:
            # 转换numpy数组为列表以便JSON序列化
            results_to_save = {k: v.tolist() if isinstance(v, np.ndarray) else v 
                              for k, v in benchmark_results.items()}
            json.dump(results_to_save, f, indent=2)
        print(f"基准测试结果已保存到: {benchmark_file}")
    
    if success:
        print("\n处理完成!")
    else:
        print("\n处理失败!")
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n程序被用户中断")
        sys.exit(0)
    except Exception as e:
        print(f"\n程序执行出错: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1) 