#!/bin/bash

# ALICE模型Jetson Nano自动安装部署脚本
# 支持JetPack 4.6.1及以上版本

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印函数
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查是否在Jetson设备上运行
check_jetson() {
    print_info "检查Jetson设备..."
    
    if ! command -v nvpmodel &> /dev/null; then
        print_error "此脚本只能在Jetson设备上运行"
        exit 1
    fi
    
    # 检查Jetson型号
    if [ -f "/proc/device-tree/model" ]; then
        MODEL=$(cat /proc/device-tree/model)
        print_info "检测到设备: $MODEL"
    fi
    
    print_success "Jetson设备检查通过"
}

# 检查系统要求
check_system() {
    print_info "检查系统要求..."
    
    # 检查内存
    MEMORY_GB=$(free -g | awk '/^Mem:/{print $2}')
    if [ "$MEMORY_GB" -lt 3 ]; then
        print_warning "内存不足4GB，建议增加交换文件"
    fi
    
    # 检查存储空间
    AVAILABLE_GB=$(df -BG / | awk 'NR==2{print $4}' | sed 's/G//')
    if [ "$AVAILABLE_GB" -lt 10 ]; then
        print_error "可用存储空间不足10GB，请清理磁盘空间"
        exit 1
    fi
    
    print_success "系统要求检查通过"
}

# 优化系统性能
optimize_system() {
    print_info "优化系统性能..."
    
    # 设置最大性能模式
    sudo nvpmodel -m 0
    sudo jetson_clocks
    
    # 创建交换文件（如果不存在）
    if [ ! -f /swapfile ]; then
        print_info "创建4GB交换文件..."
        sudo fallocate -l 4G /swapfile
        sudo chmod 600 /swapfile
        sudo mkswap /swapfile
        sudo swapon /swapfile
        
        # 添加到fstab使其永久生效
        if ! grep -q "/swapfile" /etc/fstab; then
            echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
        fi
    fi
    
    # 优化GPU内存
    if ! grep -q "nvidia NVreg_RegistryDwords" /etc/modprobe.d/nvidia.conf 2>/dev/null; then
        echo 'options nvidia NVreg_RegistryDwords="RMUseSwapMemory=0x01"' | sudo tee -a /etc/modprobe.d/nvidia.conf
    fi
    
    # 设置CPU调度器为performance
    echo performance | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor >/dev/null
    
    print_success "系统性能优化完成"
}

# 更新系统
update_system() {
    print_info "更新系统包..."
    sudo apt update
    sudo apt upgrade -y
    print_success "系统更新完成"
}

# 安装基础依赖
install_dependencies() {
    print_info "安装基础依赖..."
    
    # 系统依赖
    sudo apt install -y \
        python3-pip python3-venv python3-dev \
        git wget curl vim htop \
        build-essential cmake \
        libjpeg-dev zlib1g-dev libpython3-dev \
        libavcodec-dev libavformat-dev libswscale-dev \
        libgtk-3-dev libgstreamer1.0-dev \
        pkg-config
    
    # 安装OpenCV依赖
    sudo apt install -y \
        libopencv-dev python3-opencv \
        libopencv-contrib-dev \
        libhdf5-serial-dev hdf5-tools \
        libhdf5-dev zlib1g-dev zip \
        libjpeg8-dev liblapack-dev libblas-dev \
        gfortran
    
    print_success "基础依赖安装完成"
}

# 设置项目环境
setup_project() {
    print_info "设置项目环境..."
    
    # 设置项目目录
    PROJECT_DIR="/home/$USER/ALICE"
    VENV_DIR="$PROJECT_DIR/alice_env"
    
    # 创建项目目录
    mkdir -p "$PROJECT_DIR"
    cd "$PROJECT_DIR"
    
    # 如果是git仓库，拉取最新代码
    if [ -d ".git" ]; then
        print_info "更新代码仓库..."
        git pull
    else
        print_info "初始化项目结构..."
        # 创建基本目录结构
        mkdir -p {checkpoints/{Real,Syn},jetson_deploy,data,results}
    fi
    
    # 创建Python虚拟环境
    if [ ! -d "$VENV_DIR" ]; then
        print_info "创建Python虚拟环境..."
        python3 -m venv "$VENV_DIR"
    fi
    
    # 激活虚拟环境
    source "$VENV_DIR/bin/activate"
    
    # 升级pip
    pip install --upgrade pip
    
    print_success "项目环境设置完成"
}

# 安装PyTorch
install_pytorch() {
    print_info "安装PyTorch for Jetson..."
    
    # 检查CUDA版本
    CUDA_VERSION=$(nvcc --version | grep "release" | awk '{print $6}' | cut -c2-)
    print_info "检测到CUDA版本: $CUDA_VERSION"
    
    # 下载适用于Jetson的PyTorch wheel
    TORCH_WHL="torch-1.10.0-cp36-cp36m-linux_aarch64.whl"
    if [ ! -f "$TORCH_WHL" ]; then
        print_info "下载PyTorch wheel文件..."
        wget https://nvidia.box.com/shared/static/fjtbno0vpo676a25cgvuqc1wty0fkkg6.whl -O "$TORCH_WHL"
    fi
    
    # 安装PyTorch
    pip install "$TORCH_WHL"
    
    # 安装torchvision
    print_info "编译安装torchvision..."
    if [ ! -d "torchvision" ]; then
        git clone --branch v0.11.0 https://github.com/pytorch/vision torchvision
    fi
    
    cd torchvision
    export BUILD_VERSION=0.11.0
    python setup.py install --user
    cd ..
    
    print_success "PyTorch安装完成"
}

# 安装Python依赖包
install_python_packages() {
    print_info "安装Python依赖包..."
    
    # 基础数值计算包
    pip install numpy==1.19.5 scipy matplotlib
    
    # 图像处理包
    pip install opencv-python==4.5.3.56 Pillow==8.3.2 scikit-image==0.18.3
    
    # 深度学习相关包
    pip install einops==0.4.1 timm==0.5.4
    
    # 工具包
    pip install tqdm==4.62.3 yacs==0.1.8 natsort==8.0.0 PyWavelets==1.2.0
    
    # 性能监控包
    pip install psutil GPUtil
    
    print_success "Python依赖包安装完成"
}

# 下载预训练模型
download_model() {
    print_info "设置模型文件..."
    
    MODEL_DIR="$PROJECT_DIR/checkpoints/Real"
    MODEL_FILE="$MODEL_DIR/model_best.pth"
    
    mkdir -p "$MODEL_DIR"
    
    if [ ! -f "$MODEL_FILE" ]; then
        print_warning "预训练模型文件不存在"
        print_info "请手动将模型文件复制到: $MODEL_FILE"
        print_info "或从以下位置下载:"
        print_info "  - 项目发布页面"
        print_info "  - 云存储链接"
    else
        print_success "模型文件已存在"
    fi
}

# 创建启动脚本
create_scripts() {
    print_info "创建启动脚本..."
    
    # 创建主启动脚本
    cat > "$PROJECT_DIR/start_alice.sh" << 'EOF'
#!/bin/bash

# ALICE推理启动脚本
cd "$(dirname "$0")"

# 激活虚拟环境
source alice_env/bin/activate

# 设置性能模式
sudo nvpmodel -m 0 2>/dev/null || true
sudo jetson_clocks 2>/dev/null || true

# 设置环境变量
export CUDA_VISIBLE_DEVICES=0
export PYTHONPATH="$PWD:$PYTHONPATH"

# 启动推理
python jetson_deploy/deploy_alice.py "$@"
EOF
    
    chmod +x "$PROJECT_DIR/start_alice.sh"
    
    # 创建基准测试脚本
    cat > "$PROJECT_DIR/benchmark.sh" << 'EOF'
#!/bin/bash

cd "$(dirname "$0")"
source alice_env/bin/activate

echo "开始ALICE性能基准测试..."
python jetson_deploy/deploy_alice.py \
    --model checkpoints/Real/model_best.pth \
    --mode benchmark \
    --benchmark_iterations 100
EOF
    
    chmod +x "$PROJECT_DIR/benchmark.sh"
    
    # 创建摄像头测试脚本
    cat > "$PROJECT_DIR/camera_test.sh" << 'EOF'
#!/bin/bash

cd "$(dirname "$0")"
source alice_env/bin/activate

echo "开始摄像头实时推理..."
python jetson_deploy/deploy_alice.py \
    --model checkpoints/Real/model_best.pth \
    --mode camera \
    --color_camera 0
EOF
    
    chmod +x "$PROJECT_DIR/camera_test.sh"
    
    print_success "启动脚本创建完成"
}

# 创建桌面快捷方式
create_desktop_shortcuts() {
    print_info "创建桌面快捷方式..."
    
    # ALICE推理快捷方式
    cat > "$HOME/Desktop/ALICE_Camera.desktop" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=ALICE Camera Inference
Comment=启动ALICE实时摄像头推理
Exec=$PROJECT_DIR/camera_test.sh
Icon=applications-graphics
Terminal=true
Categories=Graphics;Photography;
EOF
    
    # 基准测试快捷方式
    cat > "$HOME/Desktop/ALICE_Benchmark.desktop" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=ALICE Benchmark
Comment=运行ALICE性能基准测试
Exec=$PROJECT_DIR/benchmark.sh
Icon=applications-system
Terminal=true
Categories=System;
EOF
    
    chmod +x "$HOME/Desktop/ALICE_"*.desktop
    
    print_success "桌面快捷方式创建完成"
}

# 运行测试
run_tests() {
    print_info "运行安装测试..."
    
    # 激活虚拟环境
    source "$PROJECT_DIR/alice_env/bin/activate"
    
    # 测试Python导入
    python3 -c "
import torch
import cv2
import numpy as np
print(f'PyTorch版本: {torch.__version__}')
print(f'CUDA可用: {torch.cuda.is_available()}')
print(f'OpenCV版本: {cv2.__version__}')
print('所有依赖包导入成功!')
" || {
        print_error "依赖包测试失败"
        exit 1
    }
    
    # 测试推理脚本
    if [ -f "$PROJECT_DIR/jetson_deploy/deploy_alice.py" ]; then
        python "$PROJECT_DIR/jetson_deploy/deploy_alice.py" --help > /dev/null || {
            print_error "推理脚本测试失败"
            exit 1
        }
    fi
    
    print_success "安装测试通过"
}

# 显示使用说明
show_usage() {
    print_success "ALICE Jetson Nano安装完成!"
    echo
    print_info "使用方法:"
    echo "  1. 实时摄像头推理:"
    echo "     ./start_alice.sh --model checkpoints/Real/model_best.pth --mode camera"
    echo
    echo "  2. 处理单张图像:"
    echo "     ./start_alice.sh --model checkpoints/Real/model_best.pth --mode image --input test.jpg"
    echo
    echo "  3. 处理视频文件:"
    echo "     ./start_alice.sh --model checkpoints/Real/model_best.pth --mode video --input video.mp4"
    echo
    echo "  4. 运行性能基准测试:"
    echo "     ./benchmark.sh"
    echo
    echo "  5. 快速摄像头测试:"
    echo "     ./camera_test.sh"
    echo
    print_info "桌面快捷方式已创建，可直接双击运行"
    echo
    print_warning "注意事项:"
    echo "  - 请确保摄像头已连接并可用"
    echo "  - 首次运行需要下载/复制模型文件到 checkpoints/Real/model_best.pth"
    echo "  - 按'q'键退出实时推理"
    echo "  - 如遇到权限问题，请使用 sudo chmod +x *.sh"
}

# 主函数
main() {
    echo "========================================"
    echo "    ALICE Jetson Nano 自动安装脚本"
    echo "========================================"
    echo
    
    # 检查参数
    SKIP_UPDATE=false
    SKIP_OPTIMIZE=false
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --skip-update)
                SKIP_UPDATE=true
                shift
                ;;
            --skip-optimize)
                SKIP_OPTIMIZE=true
                shift
                ;;
            -h|--help)
                echo "用法: $0 [选项]"
                echo "选项:"
                echo "  --skip-update    跳过系统更新"
                echo "  --skip-optimize  跳过系统优化"
                echo "  -h, --help       显示此帮助信息"
                exit 0
                ;;
            *)
                print_error "未知参数: $1"
                exit 1
                ;;
        esac
    done
    
    # 执行安装步骤
    check_jetson
    check_system
    
    if [ "$SKIP_OPTIMIZE" = false ]; then
        optimize_system
    fi
    
    if [ "$SKIP_UPDATE" = false ]; then
        update_system
    fi
    
    install_dependencies
    setup_project
    install_pytorch
    install_python_packages
    download_model
    create_scripts
    create_desktop_shortcuts
    run_tests
    show_usage
    
    print_success "安装完成! 🎉"
}

# 错误处理
trap 'print_error "安装过程中出现错误，请检查日志"; exit 1' ERR

# 运行主函数
main "$@" 