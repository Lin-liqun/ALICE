# ALICE Jetson Nano 部署快速参考卡

## 🚀 一键部署命令

```bash
# 下载并运行自动安装脚本
wget https://your-repo/install_alice_jetson.sh
chmod +x install_alice_jetson.sh
./install_alice_jetson.sh

# 复制模型文件
cp model_best.pth checkpoints/Real/

# 开始使用
./start_alice.sh --model checkpoints/Real/model_best.pth --mode camera
```

## 📋 系统要求检查清单

| 项目 | 要求 | 检查命令 |
|------|------|----------|
| 硬件 | Jetson Nano | `cat /proc/device-tree/model` |
| 系统 | JetPack 4.6.1+ | `head -n 1 /etc/nv_tegra_release` |
| 内存 | 4GB + 交换文件 | `free -h` |
| 存储 | 10GB+ 可用空间 | `df -h` |
| 摄像头 | USB/CSI | `ls /dev/video*` |
| CUDA | 10.2+ | `nvcc --version` |

## ⚡ 常用命令

### 系统优化
```bash
# 启用最大性能模式
sudo nvpmodel -m 0
sudo jetson_clocks

# 查看当前模式
sudo nvpmodel -q
```

### 推理命令
```bash
# 摄像头推理
./start_alice.sh --model checkpoints/Real/model_best.pth --mode camera

# 图像处理
./start_alice.sh --model checkpoints/Real/model_best.pth --mode image --input test.jpg

# 视频处理
./start_alice.sh --model checkpoints/Real/model_best.pth --mode video --input video.mp4

# 性能测试
./benchmark.sh
```

### 监控命令
```bash
# GPU状态
nvidia-smi

# 温度监控
cat /sys/devices/virtual/thermal/thermal_zone*/temp

# 内存使用
free -h

# 存储使用
df -h
```

## 🔧 故障排除速查

| 错误类型 | 可能原因 | 解决方案 |
|----------|----------|----------|
| `ModuleNotFoundError` | 虚拟环境未激活 | `source alice_env/bin/activate` |
| `CUDA out of memory` | GPU内存不足 | 降低输入尺寸或重启系统 |
| `No module named 'tensorrt'` | TensorRT未安装 | 跳过TensorRT优化，使用PyTorch |
| 摄像头无法打开 | 权限或设备问题 | `sudo chmod 666 /dev/video*` |
| 性能过慢 | 未启用性能模式 | `sudo nvpmodel -m 0` |
| 内存不足 | 交换文件太小 | 增加交换文件大小 |

## 📊 性能参考

### 预期FPS (Jetson Nano)
- **256×256**: 15-20 FPS
- **480×640**: 8-12 FPS  
- **720×1280**: 3-5 FPS

### 内存使用
- **系统内存**: ~2GB
- **GPU内存**: ~1.5GB
- **存储空间**: ~7GB

### 功耗
- **空闲**: ~5W
- **推理**: ~8-10W
- **最大**: ~10W

## 🔄 重启和恢复

### 系统重启后恢复
```bash
cd /home/$USER/ALICE
source alice_env/bin/activate
sudo nvpmodel -m 0
sudo jetson_clocks
```

### 虚拟环境重建
```bash
rm -rf alice_env
python3 -m venv alice_env
source alice_env/bin/activate
pip install -r requirements.txt  # 如果有的话
```

### 模型重新加载
```bash
# 检查模型文件
ls -la checkpoints/Real/model_best.pth

# 测试模型加载
python -c "import torch; torch.load('checkpoints/Real/model_best.pth')"
```

## 📁 重要文件路径

```
/home/$USER/ALICE/
├── alice_env/                    # Python虚拟环境
├── checkpoints/Real/model_best.pth  # 模型文件
├── jetson_deploy/               # 部署脚本
├── start_alice.sh              # 主启动脚本
├── benchmark.sh                # 性能测试
└── camera_test.sh             # 摄像头测试
```

## 🎯 快速测试流程

1. **环境测试**
   ```bash
   source alice_env/bin/activate
   python -c "import torch; print(torch.cuda.is_available())"
   ```

2. **模型测试**
   ```bash
   python -c "from model.ALICC import ALICC; print('Model import OK')"
   ```

3. **推理测试**
   ```bash
   ./benchmark.sh
   ```

4. **摄像头测试**
   ```bash
   ./camera_test.sh
   ```

## 📞 获取帮助

- **详细指南**: `JETSON_NANO_DEPLOYMENT_GUIDE.md`
- **目录结构**: `DIRECTORY_STRUCTURE.md`
- **部署流程**: `DEPLOYMENT_FLOWCHART.md`
- **GitHub Issues**: 项目主页Issues页面
- **Jetson论坛**: NVIDIA Developer Forums

## 💡 优化提示

1. **提升性能**
   - 使用较小的输入尺寸 (256×256)
   - 启用最大性能模式
   - 关闭不必要的后台程序

2. **节省内存**
   - 增加交换文件
   - 定期清理GPU缓存
   - 使用批处理大小为1

3. **稳定运行**
   - 确保散热良好
   - 使用高质量电源
   - 定期监控温度

---
*最后更新: $(date)* 