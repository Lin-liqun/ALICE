import torch
import torch.nn as nn
import torch.nn.functional as F
import tensorrt as trt
import pycuda.driver as cuda
import pycuda.autoinit
import numpy as np
import sys
import os
from torchvision.ops import DeformConv2d

# Add parent directory to path to import ALICE model
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from model.ALICC import ALICC


class ONNXCompatiblePixelUnshuffle(nn.Module):
    """ONNX兼容的PixelUnshuffle实现"""
    def __init__(self, downscale_factor):
        super(ONNXCompatiblePixelUnshuffle, self).__init__()
        self.downscale_factor = downscale_factor

    def forward(self, x):
        batch_size, channels, height, width = x.size()
        out_channels = channels * (self.downscale_factor ** 2)
        out_height = height // self.downscale_factor
        out_width = width // self.downscale_factor
        
        # 使用reshape和permute来实现pixel_unshuffle
        # 这些操作在ONNX中有很好的支持
        x = x.view(batch_size, channels, out_height, self.downscale_factor, out_width, self.downscale_factor)
        x = x.permute(0, 1, 3, 5, 2, 4).contiguous()
        x = x.view(batch_size, out_channels, out_height, out_width)
        return x


class ONNXCompatibleAdaptiveAvgPool2d(nn.Module):
    """ONNX兼容的AdaptiveAvgPool2d实现"""
    def __init__(self, output_size):
        super(ONNXCompatibleAdaptiveAvgPool2d, self).__init__()
        self.output_size = output_size
    
    def forward(self, x):
        if self.output_size == 1 or self.output_size == (1, 1):
            # 全局平均池化 - 使用mean操作
            return torch.mean(x, dim=(2, 3), keepdim=True)
        elif isinstance(self.output_size, tuple):
            if self.output_size[0] is None and self.output_size[1] == 1:
                # 沿宽度方向池化 (None, 1)
                return torch.mean(x, dim=3, keepdim=True)
            elif self.output_size[0] == 1 and self.output_size[1] is None:
                # 沿高度方向池化 (1, None)
                return torch.mean(x, dim=2, keepdim=True)
        
        # 对于其他情况，使用mean操作实现
        _, _, h, w = x.size()
        if isinstance(self.output_size, int):
            out_h = out_w = self.output_size
        else:
            out_h = self.output_size[0] if self.output_size[0] else h
            out_w = self.output_size[1] if self.output_size[1] else w
        
        if out_h == 1 and out_w == 1:
            return torch.mean(x, dim=(2, 3), keepdim=True)
        else:
            # 计算kernel size
            kernel_h = h // out_h
            kernel_w = w // out_w
            return F.avg_pool2d(x, kernel_size=(kernel_h, kernel_w), stride=(kernel_h, kernel_w))


class ONNXCompatibleDeformConv2d(nn.Module):
    """ONNX兼容的DeformConv2d替代实现"""
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, 
                 dilation=1, groups=1, bias=True):
        super(ONNXCompatibleDeformConv2d, self).__init__()
        
        # 使用常规卷积替代可变形卷积
        # 保持相同的参数以确保输出尺寸一致
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, 
                              stride, padding, dilation, groups, bias)
    
    def forward(self, x, offset=None, mask=None):
        # 忽略offset和mask参数，直接使用常规卷积
        # 这会损失一些性能，但确保ONNX兼容性
        return self.conv(x)


def replace_incompatible_ops_in_model(model):
    """递归替换模型中不兼容ONNX的操作"""
    for name, child in model.named_children():
        if isinstance(child, nn.PixelUnshuffle):
            # 替换PixelUnshuffle为ONNX兼容版本
            setattr(model, name, ONNXCompatiblePixelUnshuffle(child.downscale_factor))
        elif isinstance(child, nn.AdaptiveAvgPool2d):
            # 替换AdaptiveAvgPool2d为ONNX兼容版本
            setattr(model, name, ONNXCompatibleAdaptiveAvgPool2d(child.output_size))
        elif isinstance(child, DeformConv2d):
            # 替换DeformConv2d为ONNX兼容版本
            compatible_conv = ONNXCompatibleDeformConv2d(
                child.in_channels, child.out_channels, child.kernel_size,
                child.stride, child.padding, child.dilation, child.groups, 
                child.bias is not None
            )
            
            # 复制原始权重到新的卷积层
            try:
                with torch.no_grad():
                    compatible_conv.conv.weight.copy_(child.weight)
                    if child.bias is not None:
                        compatible_conv.conv.bias.copy_(child.bias)
                print(f"  ✓ 替换DeformConv2d并复制权重: {name}")
            except Exception as e:
                print(f"  ⚠ 替换DeformConv2d但权重复制失败: {name} - {e}")
            
            setattr(model, name, compatible_conv)
        else:
            # 递归处理子模块
            replace_incompatible_ops_in_model(child)
    return model

class ALICEOptimized(nn.Module):
    """优化版本的ALICE模型"""
    def __init__(self, original_model):
        super(ALICEOptimized, self).__init__()
        self.model = original_model

    def forward(self, color_img, mono_img):
        # 简化前向传播，只返回主要输出
        with torch.no_grad():
            restored_img, _, _, _ = self.model(color_img, mono_img)
        return restored_img


def convert_to_onnx(model_path, onnx_path, support_dynamic_size=True):
    """转换模型到ONNX格式"""
    # 加载预训练模型
    model = ALICC(Ch_img=3, Channels=32, state='Test', REF=True, tests=False)
    checkpoint = torch.load(model_path, map_location='cpu')
    
    # 处理不同的checkpoint格式
    if 'model' in checkpoint:
        model.load_state_dict(checkpoint['model'])
    elif 'state_dict' in checkpoint:
        model.load_state_dict(checkpoint['state_dict'])
    else:
        model.load_state_dict(checkpoint)
        
    model.eval()
    
    # 替换不兼容ONNX的操作为兼容版本
    print("替换不兼容的ONNX操作:")
    model = replace_incompatible_ops_in_model(model)
    print("操作替换完成")

    # 创建优化版本
    optimized_model = ALICEOptimized(model)
    optimized_model.eval()

    # 创建示例输入 - 训练和推理都使用480x160
    input_height, input_width = 480, 160
    color_input = torch.randn(1, 3, input_height, input_width)
    mono_input = torch.randn(1, 3, input_height, input_width)
    print(f"导出模型尺寸: {input_height}x{input_width} ({'动态' if support_dynamic_size else '固定'}尺寸)")

    # 导出ONNX
    dynamic_axes = None
    if support_dynamic_size:
        dynamic_axes = {
            'color_input': {2: 'height', 3: 'width'},
            'mono_input': {2: 'height', 3: 'width'},
            'output': {2: 'height', 3: 'width'}
        }
    
    # 尝试多个opset版本，从最兼容的开始
    export_success = False
    opset_versions = [9, 10, 11]  # 从最兼容的版本开始
    
    for opset_ver in opset_versions:
        try:
            print(f"尝试导出 ONNX (opset {opset_ver})...")
            
            # 对于较低版本，不使用动态轴
            current_dynamic_axes = dynamic_axes if opset_ver >= 10 and support_dynamic_size else None
            
            torch.onnx.export(
                optimized_model,
                (color_input, mono_input),
                onnx_path,
                export_params=True,
                opset_version=opset_ver,
                do_constant_folding=True,
                input_names=['color_input', 'mono_input'],
                output_names=['output'],
                dynamic_axes=current_dynamic_axes,
                verbose=False,
                # 添加更保守的设置
                operator_export_type=torch.onnx.OperatorExportTypes.ONNX_ATEN_FALLBACK if opset_ver == 9 else torch.onnx.OperatorExportTypes.ONNX
            )
            print(f"✓ 成功导出ONNX模型 (opset {opset_ver}): {onnx_path}")
            export_success = True
            break
            
        except Exception as e:
            print(f"✗ ONNX导出失败 (opset {opset_ver}): {e}")
            if opset_ver == opset_versions[-1]:  # 最后一次尝试
                print("所有opset版本都失败了")
    
    if not export_success:
        raise RuntimeError("无法导出ONNX模型，请检查模型兼容性")
    print(f"✓ 模型已导出到: {onnx_path}")


def build_tensorrt_engine(onnx_path, engine_path, max_batch_size=1):
    """构建TensorRT引擎"""
    TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
    builder = trt.Builder(TRT_LOGGER)
    config = builder.create_builder_config()

    # 设置内存池大小 (适合Jetson Nano的4GB内存)
    config.max_workspace_size = 1 << 28  # 256MB

    # 启用FP16精度以提高性能
    if builder.platform_has_fast_fp16:
        config.set_flag(trt.BuilderFlag.FP16)

    # 解析ONNX模型
    network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
    parser = trt.OnnxParser(network, TRT_LOGGER)

    with open(onnx_path, 'rb') as model:
        if not parser.parse(model.read()):
            print('ERROR: Failed to parse the ONNX file.')
            for error in range(parser.num_errors):
                print(parser.get_error(error))
            return None

    # 构建引擎
    engine = builder.build_engine(network, config)

    # 保存引擎
    with open(engine_path, 'wb') as f:
        f.write(engine.serialize())

    print(f"TensorRT引擎已保存到: {engine_path}")
    return engine


if __name__ == "__main__":
    model_path = "/home/jetson/ALICE/checkpoints/Real/model_best.pth"
    onnx_path = "/home/jetson/ALICE/checkpoints/Real/alice_optimized_480x160.onnx"
    engine_path = "/home/jetson/ALICE/checkpoints/Real/alice_optimized_480x160.trt"
    
    print("=== ALICE模型ONNX转换 ===")
    print("模型尺寸: 480x160 (训练和推理使用相同尺寸)")
    print()
    
    # 配置选项
    support_dynamic_size = False  # 使用固定尺寸，更稳定
    
    print("转换配置:")
    print(f"  - 输入尺寸: 480x160")
    print(f"  - 动态尺寸: {'是' if support_dynamic_size else '否'}")
    print(f"  - 输出ONNX: {onnx_path}")
    print(f"  - 输出TensorRT: {engine_path}")
    print()
    
    # 转换到ONNX
    print("=== 开始ONNX转换 ===")
    convert_to_onnx(model_path, onnx_path, support_dynamic_size)
    
    # 构建TensorRT引擎
    print("\n=== 构建TensorRT引擎 ===")
    try:
        build_tensorrt_engine(onnx_path, engine_path)
        print(f"\n✓ 转换完成！")
        print(f"  - ONNX模型: {onnx_path}")
        print(f"  - TensorRT引擎: {engine_path}")
    except Exception as e:
        print(f"✗ TensorRT引擎构建失败: {e}")
        print("  建议检查TensorRT版本和ONNX模型兼容性")
