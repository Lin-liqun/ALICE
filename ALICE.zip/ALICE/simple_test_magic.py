from magic_academy import solve_magic_academy

# 测试示例1
n, m, M = 1, 1, 5
power = [10]
mana = [5]
bonus = [2]

result = solve_magic_academy(n, m, M, power, mana, bonus)
print(result) 