s = input().strip()

if len(s) != 9 or not (s[0].isupper() and s[1].isupper() and s[0].isalpha() and s[1].isalpha()) or not s[2:8].isdigit():
    print("Invalid")
else:
    print(s[:8] + chr((sum(ord(c) for c in s[:8]) % 26) + ord('A'))) 