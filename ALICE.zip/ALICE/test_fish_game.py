from fish_game import solve_fish_simple

def test_fish_game():
    """测试大鱼吃小鱼游戏"""
    
    print("=== 测试示例1 ===")
    n1 = 4
    a1 = [3, 2, 4, 2]
    result1 = solve_fish_simple(n1, a1)
    expected1 = [2, 1, 2, 1]
    print(f"输入: n={n1}, a={a1}")
    print(f"输出: {result1}")
    print(f"期望: {expected1}")
    print(f"正确: {result1 == expected1}")
    print()
    
    # 手动验证过程
    print("=== 手动验证过程 ===")
    print("初始状态: [3, 2, 4, 2]")
    print("可能的游戏过程:")
    print("1. 鱼3(血量4)吃掉鱼2(血量2) -> [3, 6, 2]")
    print("2. 鱼1(血量3)吃掉鱼4(血量2) -> [3, 6] 或者 鱼2(血量6)吃掉鱼4(血量2) -> [3, 8]")
    print("3. 继续游戏直到只剩一条鱼")
    print()
    
    print("=== 测试简单情况 ===")
    # 测试只有两条鱼的情况
    n2 = 2
    a2 = [3, 2]
    result2 = solve_fish_simple(n2, a2)
    print(f"两条鱼 {a2}: {result2}")
    
    # 测试三条鱼
    n3 = 3
    a3 = [2, 3, 1]
    result3 = solve_fish_simple(n3, a3)
    print(f"三条鱼 {a3}: {result3}")
    
    # 测试无法被吃掉的情况
    n4 = 3
    a4 = [1, 2, 3]
    result4 = solve_fish_simple(n4, a4)
    print(f"递增序列 {a4}: {result4}")
    
    # 测试所有鱼血量相同
    n5 = 3
    a5 = [2, 2, 2]
    result5 = solve_fish_simple(n5, a5)
    print(f"相同血量 {a5}: {result5}")


if __name__ == "__main__":
    test_fish_game() 