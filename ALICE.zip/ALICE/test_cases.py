from network_node_detection import min_test_packets

def test_cases():
    # 测试示例1: 2个节点，60分钟传输，60分钟总时间
    result1 = min_test_packets(2, 60, 60)
    print(f"示例1: numbers=2, transmit=60, total=60 -> {result1} (期望: 1)")
    
    # 测试失败案例: 4个节点，15分钟传输，15分钟总时间
    result_fail = min_test_packets(4, 15, 15)
    print(f"失败案例: numbers=4, transmit=15, total=15 -> {result_fail} (期望: 2)")
    
    # 测试其他情况
    # 情况2: 4个节点，30分钟传输，60分钟总时间 (可以进行2轮)
    result2 = min_test_packets(4, 30, 60)
    print(f"测试2: numbers=4, transmit=30, total=60 -> {result2}")
    
    # 情况3: 8个节点，20分钟传输，60分钟总时间 (可以进行3轮)
    result3 = min_test_packets(8, 20, 60)
    print(f"测试3: numbers=8, transmit=20, total=60 -> {result3}")
    
    # 情况4: 10个节点，60分钟传输，60分钟总时间 (只能进行1轮)
    result4 = min_test_packets(10, 60, 60)
    print(f"测试4: numbers=10, transmit=60, total=60 -> {result4}")
    
    # 情况5: 1个节点
    result5 = min_test_packets(1, 60, 60)
    print(f"测试5: numbers=1, transmit=60, total=60 -> {result5}")
    
    # 更多测试案例
    result6 = min_test_packets(8, 60, 60)
    print(f"测试6: numbers=8, transmit=60, total=60 -> {result6} (期望: 3)")
    
    result7 = min_test_packets(16, 60, 60)
    print(f"测试7: numbers=16, transmit=60, total=60 -> {result7} (期望: 4)")

if __name__ == "__main__":
    test_cases()
