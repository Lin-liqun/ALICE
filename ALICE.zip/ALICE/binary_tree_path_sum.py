def solve_binary_tree_path_sum():
    """
    解决满二叉树最短路径和问题
    
    思路：
    1. 满二叉树有 2^k - 1 个节点
    2. 中序遍历结果：左子树 → 根节点 → 右子树
    3. 对于满二叉树，根节点在中序遍历中的位置是 2^(k-1) - 1
    4. 从根节点到叶节点的最短路径就是到最底层任意一个叶节点
    5. 题目要求最短路径上节点和的最大值，即在所有最短路径中找和最大的
    """
    # 读取输入
    k = int(input())
    inorder_str = input().strip()
    # 处理输入格式：可能是空格分隔，也可能是连续数字
    if ' ' in inorder_str:
        inorder = list(map(int, inorder_str.split()))
    else:
        # 如果是连续数字，按字符分割
        inorder = [int(c) for c in inorder_str]
    
    n = 2**k - 1  # 总节点数
    
    # 构建满二叉树
    # 对于满二叉树，根节点在中序遍历中的位置是 2^(k-1) - 1
    def build_tree(left, right, level):
        """
        根据中序遍历结果构建满二叉树
        left, right: 当前子树在中序遍历中的范围
        level: 当前层数（从0开始）
        """
        if left > right:
            return None
        
        if left == right:
            return {'val': inorder[left], 'left': None, 'right': None}
        
        # 计算根节点位置
        # 对于深度为k的满二叉树，根节点位置是 2^(k-1) - 1
        # 但这里我们需要根据当前子树的大小来计算
        subtree_size = right - left + 1
        left_subtree_size = (subtree_size - 1) // 2
        root_pos = left + left_subtree_size
        
        root_val = inorder[root_pos]
        
        # 递归构建左右子树
        left_subtree = build_tree(left, root_pos - 1, level + 1)
        right_subtree = build_tree(root_pos + 1, right, level + 1)
        
        return {
            'val': root_val,
            'left': left_subtree,
            'right': right_subtree
        }
    
    # 构建树
    root = build_tree(0, n - 1, 0)
    
    def max_path_sum(node):
        """
        计算从当前节点到叶节点的最大路径和
        在满二叉树中，所有从根到叶的路径长度都相等，都是"最短路径"
        题目要求的是这些等长路径中节点和最大的
        """
        if node is None:
            return 0
        
        # 如果是叶节点
        if node['left'] is None and node['right'] is None:
            return node['val']
        
        # 如果只有左子树
        if node['right'] is None:
            return node['val'] + max_path_sum(node['left'])
        
        # 如果只有右子树
        if node['left'] is None:
            return node['val'] + max_path_sum(node['right'])
        
        # 如果有两个子树，选择路径和较大的
        left_sum = max_path_sum(node['left'])
        right_sum = max_path_sum(node['right'])
        
        return node['val'] + max(left_sum, right_sum)
    
    # 计算从根节点到叶节点的最大路径和
    result = max_path_sum(root)
    print(result)


if __name__ == "__main__":
    solve_binary_tree_path_sum()
