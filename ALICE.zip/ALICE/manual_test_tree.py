from christmas_tree_lights import solve_christmas_tree_lights

# 测试示例1
n = 5
initial = [1, 2, 3, 0, 1]
target = [2, 3, 1, 0, 2]

result = solve_christmas_tree_lights(n, initial, target)
print(result) 