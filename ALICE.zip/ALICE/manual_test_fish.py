from fish_game import solve_fish_simple

# 测试示例
n = 4
a = [3, 2, 4, 2]
result = solve_fish_simple(n, a)
print(' '.join(map(str, result))) 