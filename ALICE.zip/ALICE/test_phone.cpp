#include <iostream>
#include <vector>
#include <string>

using namespace std;

// 手动验证x=2的情况
void testCase() {
    cout << "测试x=2的情况：" << endl;
    
    // 假设b和d玩手机 (playPhone = [false, true, false, true])
    vector<bool> playPhone = {false, true, false, true};
    
    // a的话：我可没玩手机 (a没玩手机)
    bool a_statement = !playPhone[0];  // true (a确实没玩)
    cout << "a说'我可没玩手机': " << (a_statement ? "真话" : "假话") << endl;
    
    // b的话：c玩手机了 (c玩手机)
    bool b_statement = playPhone[2];   // false (c没玩)
    cout << "b说'c玩手机了': " << (b_statement ? "真话" : "假话") << endl;
    
    // c的话：玩手机的肯定是d (d玩手机)
    bool c_statement = playPhone[3];   // true (d确实玩了)
    cout << "c说'玩手机的肯定是d': " << (c_statement ? "真话" : "假话") << endl;
    
    // d的话：c胡说 (c的话是假的，即d没玩手机)
    bool d_statement = !playPhone[3];  // false (d确实玩了，所以c没胡说)
    cout << "d说'c胡说': " << (d_statement ? "真话" : "假话") << endl;
    
    // 统计说假话的人数
    int liars = 0;
    if (!a_statement) liars++;
    if (!b_statement) liars++;
    if (!c_statement) liars++;
    if (!d_statement) liars++;
    
    cout << "说假话的人数: " << liars << endl;
    cout << "玩手机的人: ";
    if (playPhone[0]) cout << "a ";
    if (playPhone[1]) cout << "b ";
    if (playPhone[2]) cout << "c ";
    if (playPhone[3]) cout << "d ";
    cout << endl;
}

int main() {
    testCase();
    return 0;
} 