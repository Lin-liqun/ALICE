class PokerWeightCalculator:
    def __init__(self):
        # 点数映射：2,3,4,5,6,7,8,9,10,J,Q,K,A 对应 0-12
        self.card_to_value = {
            '2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, '9': 7,
            '10': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12
        }
    
    def parse_cards(self, cards):
        """解析手牌，统计各点数的数量和大小王"""
        card_counts = [0] * 13  # 索引0-12对应点数2-A的数量
        has_j1 = False  # 大王
        has_j2 = False  # 小王
        
        for card in cards:
            if card == 'J1':
                has_j1 = True
            elif card == 'J2':
                has_j2 = True
            else:
                # 提取点数部分
                if len(card) == 3 and card[1:3] == '10':
                    value = '10'
                else:
                    value = card[1:]
                card_counts[self.card_to_value[value]] += 1
        
        return card_counts, has_j1, has_j2
    
    def can_form_straight(self, start, counts):
        """检查从start开始的5张连续牌是否存在"""
        if start > 8:  # A最大，所以最多到8开始(9,10,J,Q,K,A)
            return False
        for i in range(start, start + 5):
            if counts[i] == 0:
                return False
        return True
    
    def calculate_max_weight(self, counts, has_j1, has_j2):
        """递归计算最大权重"""
        max_weight = 0
        
        # 尝试双王（权重5）
        if has_j1 and has_j2:
            max_weight = max(max_weight, 5 + self.calculate_max_weight(counts[:], False, False))
        
        # 尝试四张（权重5）
        for i in range(13):
            if counts[i] >= 4:
                new_counts = counts[:]
                new_counts[i] -= 4
                max_weight = max(max_weight, 5 + self.calculate_max_weight(new_counts, has_j1, has_j2))
        
        # 尝试三张（权重4）
        for i in range(13):
            if counts[i] >= 3:
                new_counts = counts[:]
                new_counts[i] -= 3
                max_weight = max(max_weight, 4 + self.calculate_max_weight(new_counts, has_j1, has_j2))
        
        # 尝试单顺（权重3）
        for start in range(9):  # 0-8，对应2-10开始的顺子
            if self.can_form_straight(start, counts):
                new_counts = counts[:]
                for i in range(start, start + 5):
                    new_counts[i] -= 1
                max_weight = max(max_weight, 3 + self.calculate_max_weight(new_counts, has_j1, has_j2))
        
        # 尝试对牌（权重2）
        for i in range(13):
            if counts[i] >= 2:
                new_counts = counts[:]
                new_counts[i] -= 2
                max_weight = max(max_weight, 2 + self.calculate_max_weight(new_counts, has_j1, has_j2))
        
        # 剩余的都是单牌，权重为0，不需要计算
        return max_weight
    
    def solve(self, cards):
        """求解最大权重"""
        counts, has_j1, has_j2 = self.parse_cards(cards)
        return self.calculate_max_weight(counts, has_j1, has_j2)


def main():
    n = int(input())
    cards = []
    for _ in range(n):
        cards.append(input().strip())
    
    calculator = PokerWeightCalculator()
    result = calculator.solve(cards)
    print(result)


if __name__ == "__main__":
    main() 