def solve():
    s = input().strip()
    
    # 检查长度
    if len(s) != 9:
        return "Invalid"
    
    # 检查前2位是否为大写字母
    if not (s[0].isupper() and s[0].isalpha() and s[1].isupper() and s[1].isalpha()):
        return "Invalid"
    
    # 检查第3-8位是否为数字
    if not s[2:8].isdigit():
        return "Invalid"
    
    # 计算正确的校验位
    ascii_sum = sum(ord(c) for c in s[:8])
    correct_check = chr((ascii_sum % 26) + ord('A'))
    
    # 返回修复后的单号
    return s[:8] + correct_check

print(solve()) 