from christmas_tree_lights import solve_christmas_tree_lights

def test_christmas_tree():
    """测试二叉树彩灯控制功能"""
    
    # 测试示例1
    n1 = 5
    initial1 = [1, 2, 3, 0, 1]
    target1 = [2, 3, 1, 0, 2]
    result1 = solve_christmas_tree_lights(n1, initial1, target1)
    print(f"示例1结果: {result1}")
    
    # 测试简单情况
    n2 = 3
    initial2 = [1, 2, 3]
    target2 = [2, 3, 4]
    result2 = solve_christmas_tree_lights(n2, initial2, target2)
    print(f"简单测试结果: {result2}")


if __name__ == "__main__":
    test_christmas_tree() 