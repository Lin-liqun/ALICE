#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

bool checkConsistency(vector<bool> playPhone, int x) {
    // a的话：我可没玩手机 (a没玩手机)
    bool a_statement = !playPhone[0];
    
    // b的话：c玩手机了 (c玩手机)
    bool b_statement = playPhone[2];
    
    // c的话：玩手机的肯定是d (d玩手机)
    bool c_statement = playPhone[3];
    
    // d的话：c胡说 (c的话是假的，即d没玩手机)
    bool d_statement = !playPhone[3];
    
    // 统计说假话的人数
    int liars = 0;
    if (!a_statement) liars++;
    if (!b_statement) liars++;
    if (!c_statement) liars++;
    if (!d_statement) liars++;
    
    return liars == x;
}

vector<string> solve(int x) {
    vector<string> result;
    bool found = false;
    
    // 枚举所有可能的玩手机情况 (2^4 = 16种)
    for (int mask = 0; mask < 16; mask++) {
        vector<bool> playPhone(4);
        playPhone[0] = (mask & 1) != 0;  // a
        playPhone[1] = (mask & 2) != 0;  // b
        playPhone[2] = (mask & 4) != 0;  // c
        playPhone[3] = (mask & 8) != 0;  // d
        
        if (checkConsistency(playPhone, x)) {
            vector<string> current;
            if (playPhone[0]) current.push_back("a");
            if (playPhone[1]) current.push_back("b");
            if (playPhone[2]) current.push_back("c");
            if (playPhone[3]) current.push_back("d");
            
            if (!found) {
                result = current;
                found = true;
            }
            else if (current < result) {
                result = current;
            }
        }
    }
    
    return result;
}

void printResult(vector<string> result) {
    cout << "[";
    for (int i = 0; i < result.size(); i++) {
        if (i > 0) cout << ",";
        cout << "'" << result[i] << "'";
    }
    cout << "]";
}

int main() {
    cout << "测试所有可能的x值：" << endl;
    
    for (int x = 0; x <= 4; x++) {
        cout << "x = " << x << ": ";
        vector<string> result = solve(x);
        printResult(result);
        cout << endl;
    }
    
    // 特别验证x=2的情况
    cout << "\n详细验证x=2的情况：" << endl;
    vector<bool> testCase = {false, true, false, true}; // b和d玩手机
    
    cout << "假设b和d玩手机：" << endl;
    cout << "a说'我可没玩手机'(a没玩): " << (!testCase[0] ? "真话" : "假话") << endl;
    cout << "b说'c玩手机了'(c没玩): " << (testCase[2] ? "真话" : "假话") << endl;
    cout << "c说'玩手机的肯定是d'(d玩了): " << (testCase[3] ? "真话" : "假话") << endl;
    cout << "d说'c胡说'(c说真话): " << (!testCase[3] ? "真话" : "假话") << endl;
    
    int liars = 0;
    if (testCase[0]) liars++;      // a说假话
    if (!testCase[2]) liars++;     // b说假话
    if (!testCase[3]) liars++;     // c说假话
    if (testCase[3]) liars++;      // d说假话
    
    cout << "说假话的人数: " << liars << endl;
    
    return 0;
} 