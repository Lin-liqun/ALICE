class UnionFind:
    """并查集数据结构，用于高效判断连通性"""
    def __init__(self, n):
        self.parent = list(range(n))
        self.rank = [0] * n
    
    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # 路径压缩
        return self.parent[x]
    
    def union(self, x, y):
        px, py = self.find(x), self.find(y)
        if px == py:
            return
        # 按秩合并
        if self.rank[px] < self.rank[py]:
            px, py = py, px
        self.parent[py] = px
        if self.rank[px] == self.rank[py]:
            self.rank[px] += 1
    
    def connected(self, x, y):
        return self.find(x) == self.find(y)

def min_escape_time(grid):
    """
    计算最短撤离时间
    使用并查集优化算法：按海拔从低到高逐步添加村落，直到起点和终点连通
    
    Args:
        grid: 二维数组表示村落海拔
    
    Returns:
        int: 最短撤离时间
    """
    n = len(grid)
    
    # 特殊情况：只有一个村落
    if n == 1:
        return grid[0][0]
    
    # 创建所有村落的列表，按海拔排序
    villages = []
    for i in range(n):
        for j in range(n):
            villages.append((grid[i][j], i, j))
    
    villages.sort()  # 按海拔从低到高排序
    
    # 初始化并查集
    uf = UnionFind(n * n)
    
    # 将二维坐标转换为一维索引
    def get_index(i, j):
        return i * n + j
    
    # 四个方向
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    
    # 记录哪些村落已经被淹没（可以访问）
    flooded = [[False] * n for _ in range(n)]
    
    start_idx = get_index(0, 0)
    end_idx = get_index(n - 1, n - 1)
    
    # 按海拔从低到高逐步添加村落
    for height, i, j in villages:
        # 标记当前村落为已淹没
        flooded[i][j] = True
        current_idx = get_index(i, j)
        
        # 与相邻的已淹没村落连接
        for di, dj in directions:
            ni, nj = i + di, j + dj
            if 0 <= ni < n and 0 <= nj < n and flooded[ni][nj]:
                neighbor_idx = get_index(ni, nj)
                uf.union(current_idx, neighbor_idx)
        
        # 检查起点和终点是否连通
        if uf.connected(start_idx, end_idx):
            return height
    
    # 理论上不应该到达这里，因为所有村落最终都会被淹没
    return max(max(row) for row in grid)

def solve():
    """ACM模式的主函数"""
    # 读取输入
    n = int(input().strip())
    grid = []
    
    for _ in range(n):
        row = list(map(int, input().strip().split()))
        grid.append(row)
    
    # 计算结果
    result = min_escape_time(grid)
    
    # 输出结果
    print(result)

if __name__ == "__main__":
    solve()
