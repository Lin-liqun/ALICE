def validate_and_fix_express_number(express_number):
    """
    校验和修复快递单号
    
    Args:
        express_number: 待校验的快递单号字符串
    
    Returns:
        str: 修复后的单号或"Invalid"
    """
    # 检查长度是否为9位
    if len(express_number) != 9:
        return "Invalid"
    
    # 提取前8位和校验位
    prefix = express_number[:8]
    check_digit = express_number[8]
    
    # 检查前2位是否为大写字母
    if not (prefix[0].isupper() and prefix[0].isalpha() and 
            prefix[1].isupper() and prefix[1].isalpha()):
        return "Invalid"
    
    # 检查第3-8位是否为数字
    if not prefix[2:8].isdigit():
        return "Invalid"
    
    # 计算正确的校验位
    ascii_sum = sum(ord(char) for char in prefix)
    correct_check_digit = chr((ascii_sum % 26) + ord('A'))
    
    # 如果校验位正确，返回原单号
    if check_digit == correct_check_digit:
        return express_number
    
    # 如果校验位错误但格式正确，返回修复后的单号
    return prefix + correct_check_digit


def main():
    """ACM模式主函数"""
    # 读取输入
    express_number = input().strip()
    
    # 处理并输出结果
    result = validate_and_fix_express_number(express_number)
    print(result)


if __name__ == "__main__":
    main() 