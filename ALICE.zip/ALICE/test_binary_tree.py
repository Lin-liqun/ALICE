#!/usr/bin/env python3
"""
测试满二叉树最短路径和算法
"""

def build_tree(inorder, left, right):
    """根据中序遍历结果构建满二叉树"""
    if left > right:
        return None
    
    if left == right:
        return {'val': inorder[left], 'left': None, 'right': None}
    
    # 计算根节点位置
    subtree_size = right - left + 1
    left_subtree_size = (subtree_size - 1) // 2
    root_pos = left + left_subtree_size
    
    root_val = inorder[root_pos]
    
    # 递归构建左右子树
    left_subtree = build_tree(inorder, left, root_pos - 1)
    right_subtree = build_tree(inorder, root_pos + 1, right)
    
    return {
        'val': root_val,
        'left': left_subtree,
        'right': right_subtree
    }

def min_path_sum(node):
    """计算从当前节点到叶节点的最短路径和"""
    if node is None:
        return 0
    
    # 如果是叶节点
    if node['left'] is None and node['right'] is None:
        return node['val']
    
    # 如果只有左子树
    if node['right'] is None:
        return node['val'] + min_path_sum(node['left'])
    
    # 如果只有右子树
    if node['left'] is None:
        return node['val'] + min_path_sum(node['right'])
    
    # 如果有两个子树，选择路径和较小的
    left_sum = min_path_sum(node['left'])
    right_sum = min_path_sum(node['right'])
    
    return node['val'] + min(left_sum, right_sum)

def test_cases():
    """测试各种情况"""
    test_cases = [
        # 示例1: k=2, inorder=[2,1,4]
        (2, [2, 1, 4], 5),
        
        # 测试k=1的情况
        (1, [1], 1),
        
        # 测试k=3的情况
        (3, [4, 2, 5, 1, 6, 3, 7], 7),  # 应该是1+2+4=7
        
        # 其他测试
        (2, [1, 2, 3], 3),  # 应该是2+1=3
    ]
    
    print("测试满二叉树最短路径和算法：")
    print("=" * 50)
    
    for i, (k, inorder, expected) in enumerate(test_cases, 1):
        n = 2**k - 1
        root = build_tree(inorder, 0, n - 1)
        result = min_path_sum(root)
        status = "✓" if result == expected else "✗"
        
        print(f"测试 {i}: {status}")
        print(f"  深度 k = {k}")
        print(f"  中序遍历: {inorder}")
        print(f"  期望结果: {expected}")
        print(f"  实际结果: {result}")
        if result != expected:
            print(f"  ❌ 不匹配!")
        print()

def print_tree_structure():
    """打印树结构帮助理解"""
    print("\n满二叉树结构示例 (k=2, inorder=[2,1,4]):")
    print("    1")
    print("   / \\")
    print("  2   4")
    print("中序遍历: 2 → 1 → 4")
    print("从根节点1到叶节点的路径:")
    print("  1 → 2: 和为 1+2=3")
    print("  1 → 4: 和为 1+4=5")
    print("最短路径和: min(3, 5) = 3")
    print("但题目要求的是最大路径和，所以是 5")

if __name__ == "__main__":
    test_cases()
    print_tree_structure()






