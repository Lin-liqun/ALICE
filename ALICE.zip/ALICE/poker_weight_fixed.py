def solve_poker_weight(cards):
    # 点数映射
    value_map = {'2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, '9': 7,
                 '10': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12}
    
    # 统计各点数数量和大小王
    counts = [0] * 13
    has_j1 = False
    has_j2 = False
    
    for card in cards:
        if card == 'J1':
            has_j1 = True
        elif card == 'J2':
            has_j2 = True
        else:
            # 提取点数
            if len(card) == 3 and card[1:3] == '10':
                value = '10'
            else:
                value = card[1:]
            counts[value_map[value]] += 1
    
    def can_form_straight(start, card_counts):
        """检查是否能组成从start开始的单顺"""
        if start > 8:  # 最多到8开始(9,10,J,Q,K,A)
            return False
        for i in range(start, start + 5):
            if card_counts[i] == 0:
                return False
        return True
    
    def dfs(card_counts, j1, j2):
        """深度优先搜索计算最大权重"""
        max_weight = 0
        
        # 尝试双王
        if j1 and j2:
            max_weight = max(max_weight, 5 + dfs(card_counts[:], False, False))
        
        # 尝试四张
        for i in range(13):
            if card_counts[i] >= 4:
                new_counts = card_counts[:]
                new_counts[i] -= 4
                max_weight = max(max_weight, 5 + dfs(new_counts, j1, j2))
        
        # 尝试三张
        for i in range(13):
            if card_counts[i] >= 3:
                new_counts = card_counts[:]
                new_counts[i] -= 3
                max_weight = max(max_weight, 4 + dfs(new_counts, j1, j2))
        
        # 尝试单顺
        for start in range(9):
            if can_form_straight(start, card_counts):
                new_counts = card_counts[:]
                for i in range(start, start + 5):
                    new_counts[i] -= 1
                max_weight = max(max_weight, 3 + dfs(new_counts, j1, j2))
        
        # 尝试对牌
        for i in range(13):
            if card_counts[i] >= 2:
                new_counts = card_counts[:]
                new_counts[i] -= 2
                max_weight = max(max_weight, 2 + dfs(new_counts, j1, j2))
        
        return max_weight
    
    return dfs(counts, has_j1, has_j2)


# 主程序
if __name__ == "__main__":
    n = int(input())
    cards = []
    for _ in range(n):
        cards.append(input().strip())
    
    result = solve_poker_weight(cards)
    print(result) 