# GAN生成器实现

这是一个简单的生成对抗网络（GAN）生成器实现，能够根据输入的随机噪声和真实数据生成假数据样本。

## 功能描述

生成器通过以下公式生成假数据：
```
假数据 = 真实数据 + 随机噪声
```

## 文件说明

1. **`generator_gan.py`** - 基础实现，满足题目要求
2. **`advanced_generator.py`** - 高级实现，包含类结构和统计功能
3. **`test_generator.py`** - 基础测试文件
4. **`comprehensive_test.py`** - 全面测试套件

## 使用方法

### 基础版本
```bash
python generator_gan.py
```

### 高级版本（带统计信息）
```bash
python advanced_generator.py --stats
```

## 输入格式

```
N D
noise_1_1 noise_1_2 ... noise_1_D
noise_2_1 noise_2_2 ... noise_2_D
...
noise_N_1 noise_N_2 ... noise_N_D
real_1_1 real_1_2 ... real_1_D
real_2_1 real_2_2 ... real_2_D
...
real_N_1 real_N_2 ... real_N_D
```

- `N`: 样本数量
- `D`: 特征数量
- 前N行: 随机噪声数据
- 后N行: 真实数据

## 输出格式

每行输出一个生成的假数据样本，数值保留两位小数，用空格分隔。

## 示例

### 输入：
```
1 5
-0.04 -0.75 0.3 0.36 -0.07
0.5 -0.14 0.65 1.52 -0.23
```

### 输出：
```
0.46 -0.89 0.95 1.88 -0.30
```

## 测试

运行测试套件：
```bash
python comprehensive_test.py
```

## 支持的库

- `numpy` - 数值计算
- `pandas` - 数据处理
- `scipy` - 科学计算
- `scikit-learn` - 机器学习

## 特性

✅ 支持多样本、多特征数据  
✅ 精确的数值计算  
✅ 错误处理和验证  
✅ 统计信息输出  
✅ 全面的测试覆盖  
✅ 代码结构清晰，易于扩展 