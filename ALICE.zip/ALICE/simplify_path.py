def simplifyPath(path):
    """
    简化Unix风格的绝对路径
    
    规则：
    - '.' 表示当前目录
    - '..' 表示上级目录
    - 多个连续的'/'视为单个'/'
    - 结果必须以'/'开头，不能以'/'结尾（除非是根目录）
    """
    # 使用栈来存储路径组件
    stack = []
    
    # 按'/'分割路径，过滤掉空字符串
    components = [comp for comp in path.split('/') if comp and comp != '.']
    
    for component in components:
        if component == '..':
            # 如果是'..'且栈不为空，则弹出栈顶元素（返回上级目录）
            if stack:
                stack.pop()
        else:
            # 其他情况，将组件压入栈
            stack.append(component)
    
    # 构建结果路径
    # 如果栈为空，说明是根目录
    if not stack:
        return '/'
    
    # 否则，用'/'连接所有组件，并在前面加上'/'
    return '/' + '/'.join(stack)


# ACM模式输入输出
if __name__ == "__main__":
    # 读取输入
    path = input().strip()
    
    # 计算简化后的路径
    result = simplifyPath(path)
    
    # 输出结果
    print(result)






