#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>

using namespace std;

class PokerWeightCalculator {
private:
    map<string, int> cardToValue;
    vector<int> cardCounts; // 索引0-12对应点数2-A的数量
    bool hasJ1, hasJ2; // 大王小王
    
    void initCardMapping() {
        string values[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        for (int i = 0; i < 13; i++) {
            cardToValue[values[i]] = i;
        }
    }
    
    void parseCards(vector<string>& cards) {
        cardCounts.assign(13, 0);
        hasJ1 = hasJ2 = false;
        
        for (string& card : cards) {
            if (card == "J1") {
                hasJ1 = true;
            } else if (card == "J2") {
                hasJ2 = true;
            } else {
                // 提取点数部分
                string value;
                if (card.length() == 3 && card.substr(1, 2) == "10") {
                    value = "10";
                } else {
                    value = card.substr(1);
                }
                cardCounts[cardToValue[value]]++;
            }
        }
    }
    
    // 检查从start开始的5张连续牌是否存在
    bool canFormStraight(int start, const vector<int>& counts) {
        if (start > 8) return false; // A最大，所以最多到8开始(9,10,J,Q,K,A对应索引8-12)
        for (int i = start; i < start + 5; i++) {
            if (counts[i] == 0) return false;
        }
        return true;
    }
    
    // 递归计算最大权重
    int calculateMaxWeight(vector<int> counts, bool j1, bool j2) {
        int maxWeight = 0;
        
        // 检查是否还有牌可以组成牌型
        bool hasCards = false;
        for (int i = 0; i < 13; i++) {
            if (counts[i] > 0) {
                hasCards = true;
                break;
            }
        }
        if (!hasCards && !j1 && !j2) {
            return 0; // 没有牌了，返回0
        }
        
        // 尝试双王
        if (j1 && j2) {
            maxWeight = max(maxWeight, 5 + calculateMaxWeight(counts, false, false));
        }
        
        // 尝试四张
        for (int i = 0; i < 13; i++) {
            if (counts[i] >= 4) {
                vector<int> newCounts = counts;
                newCounts[i] -= 4;
                maxWeight = max(maxWeight, 5 + calculateMaxWeight(newCounts, j1, j2));
            }
        }
        
        // 尝试三张
        for (int i = 0; i < 13; i++) {
            if (counts[i] >= 3) {
                vector<int> newCounts = counts;
                newCounts[i] -= 3;
                maxWeight = max(maxWeight, 4 + calculateMaxWeight(newCounts, j1, j2));
            }
        }
        
        // 尝试单顺
        for (int start = 0; start <= 8; start++) {
            if (canFormStraight(start, counts)) {
                vector<int> newCounts = counts;
                for (int i = start; i < start + 5; i++) {
                    newCounts[i]--;
                }
                maxWeight = max(maxWeight, 3 + calculateMaxWeight(newCounts, j1, j2));
            }
        }
        
        // 尝试对牌
        for (int i = 0; i < 13; i++) {
            if (counts[i] >= 2) {
                vector<int> newCounts = counts;
                newCounts[i] -= 2;
                maxWeight = max(maxWeight, 2 + calculateMaxWeight(newCounts, j1, j2));
            }
        }
        
        // 剩余的都是单牌，权重为0，不需要计算
        
        return maxWeight;
    }
    
public:
    PokerWeightCalculator() {
        initCardMapping();
    }
    
    int solve(vector<string>& cards) {
        parseCards(cards);
        return calculateMaxWeight(cardCounts, hasJ1, hasJ2);
    }
};

int main() {
    int n;
    cin >> n;
    
    vector<string> cards(n);
    for (int i = 0; i < n; i++) {
        cin >> cards[i];
    }
    
    PokerWeightCalculator calculator;
    cout << calculator.solve(cards) << endl;
    
    return 0;
} 