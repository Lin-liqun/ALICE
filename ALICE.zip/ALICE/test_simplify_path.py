#!/usr/bin/env python3
"""
测试简化路径的代码
"""

def simplifyPath(path):
    """
    简化Unix风格的绝对路径
    """
    stack = []
    components = [comp for comp in path.split('/') if comp and comp != '.']
    
    for component in components:
        if component == '..':
            if stack:
                stack.pop()
        else:
            stack.append(component)
    
    if not stack:
        return '/'
    
    return '/' + '/'.join(stack)


def test_cases():
    """测试各种情况"""
    test_cases = [
        # 基本测试
        ("/home/", "/home"),
        ("/../", "/"),
        ("/home//foo/", "/home/foo"),
        ("/a/./b/../../c/", "/c"),
        ("/a/../../b/../c//.//", "/c"),
        ("/a//b////c/d//././/..", "/a/b/c"),
        
        # 边界情况
        ("/", "/"),
        ("/..", "/"),
        ("/...", "/..."),
        ("/home/../", "/"),
        ("/home/../home", "/home"),
        ("/home/../home/", "/home"),
        ("/home/../home/../", "/"),
        ("/home/../home/../home", "/home"),
        
        # 复杂情况
        ("/a/./b/../../c/", "/c"),
        ("/a/../../b/../c//.//", "/c"),
        ("/a//b////c/d//././/..", "/a/b/c"),
        ("/home/foo/../bar/../baz/", "/home/baz"),
    ]
    
    print("测试简化路径功能：")
    print("=" * 50)
    
    for i, (input_path, expected) in enumerate(test_cases, 1):
        result = simplifyPath(input_path)
        status = "✓" if result == expected else "✗"
        print(f"测试 {i:2d}: {status}")
        print(f"  输入: {input_path}")
        print(f"  期望: {expected}")
        print(f"  实际: {result}")
        if result != expected:
            print(f"  ❌ 不匹配!")
        print()


if __name__ == "__main__":
    test_cases()






