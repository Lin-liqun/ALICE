from flood_escape import min_escape_time

def test_examples():
    print("测试优化后的并查集算法...")
    
    # 示例1
    grid1 = [
        [0, 2],
        [1, 3]
    ]
    result1 = min_escape_time(grid1)
    print(f"示例1结果: {result1} (期望: 3)")
    
    # 验证示例1的逻辑：
    # 按海拔排序: (0,0):0 -> (1,0):1 -> (0,1):2 -> (1,1):3
    # 当添加海拔3的村落(1,1)时，起点(0,0)和终点(1,1)才连通
    
    # 示例2
    grid2 = [
        [0, 1, 2, 3, 4],
        [24, 23, 22, 21, 5],
        [12, 13, 14, 15, 16],
        [11, 17, 18, 19, 20],
        [10, 9, 8, 7, 6]
    ]
    result2 = min_escape_time(grid2)
    print(f"示例2结果: {result2} (期望: 16)")
    
    # 手动验证一些简单情况
    # 测试3: 简单的递增路径
    grid3 = [
        [0, 1],
        [2, 3]
    ]
    result3 = min_escape_time(grid3)
    print(f"测试3结果: {result3} (期望: 3)")
    
    # 测试4: 单个村落
    grid4 = [[5]]
    result4 = min_escape_time(grid4)
    print(f"测试4结果: {result4} (期望: 5)")
    
    # 测试5: 更复杂的情况
    grid5 = [
        [0, 10, 20],
        [5, 15, 25],
        [1, 2, 3]
    ]
    result5 = min_escape_time(grid5)
    print(f"测试5结果: {result5}")
    
    print("算法复杂度分析:")
    print("- 时间复杂度: O(n²log(n²)) = O(n²logn) 用于排序")
    print("- 空间复杂度: O(n²) 用于并查集和辅助数组")
    print("- 相比二分搜索+BFS的O(n²log(max_height) * n²)，效率大幅提升")

if __name__ == "__main__":
    test_examples()
