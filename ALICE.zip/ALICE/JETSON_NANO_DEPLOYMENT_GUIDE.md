# ALICE模型在Jetson Nano上的完整部署指南

## 概述
本指南详细介绍如何将ALICE (Aerial Low-light Imaging with Color-monochrome Engagement) 模型部署到NVIDIA Jetson Nano开发板上。ALICE是一个用于低光照航拍图像增强的深度学习模型，采用彩色-单色双摄像头融合技术。

## 目录
1. [硬件要求](#硬件要求)
2. [系统准备](#系统准备)
3. [环境配置](#环境配置)
4. [模型优化](#模型优化)
5. [部署代码](#部署代码)
6. [性能优化](#性能优化)
7. [实时推理](#实时推理)
8. [故障排除](#故障排除)

## 硬件要求

### Jetson Nano规格
- **GPU**: 128-core Maxwell GPU
- **CPU**: Quad-core ARM A57 @ 1.43 GHz
- **内存**: 4GB 64-bit LPDDR4 25.6 GB/s
- **存储**: microSD卡 (建议64GB以上，Class 10)
- **功耗**: 5W-10W

### 推荐配置
- Jetson Nano Developer Kit
- 高速microSD卡 (64GB+, UHS-I U3)
- 5V 4A电源适配器
- 散热风扇或散热片
- USB摄像头或CSI摄像头 (支持彩色+单色双摄)

## 系统准备

### 1. 烧录JetPack系统
```bash
# 下载最新的JetPack 4.6.1镜像
# 从NVIDIA官网下载：https://developer.nvidia.com/jetpack-sdk-461

# 使用Etcher或dd命令烧录到microSD卡
sudo dd if=jetpack-4.6.1.img of=/dev/sdX bs=1M status=progress
```

### 2. 初始系统设置
```bash
# 启动Jetson Nano并完成初始设置
# 连接WiFi/以太网
# 更新系统
sudo apt update && sudo apt upgrade -y

# 安装基础工具
sudo apt install -y git wget curl vim htop
```

### 3. 启用最大性能模式
```bash
# 设置最大性能模式
sudo nvpmodel -m 0
sudo jetson_clocks

# 检查当前状态
sudo nvpmodel -q
```

## 环境配置

### 1. 安装Python依赖管理
```bash
# 安装pip和虚拟环境
sudo apt install -y python3-pip python3-venv python3-dev

# 创建虚拟环境
python3 -m venv alice_env
source alice_env/bin/activate
```

### 2. 安装PyTorch for Jetson
```bash
# 下载适用于Jetson的PyTorch wheel文件
wget https://nvidia.box.com/shared/static/fjtbno0vpo676a25cgvuqc1wty0fkkg6.whl -O torch-1.10.0-cp36-cp36m-linux_aarch64.whl

# 安装PyTorch
pip install torch-1.10.0-cp36-cp36m-linux_aarch64.whl

# 安装torchvision
sudo apt install -y libjpeg-dev zlib1g-dev libpython3-dev libavcodec-dev libavformat-dev libswscale-dev
git clone --branch v0.11.0 https://github.com/pytorch/vision torchvision
cd torchvision
export BUILD_VERSION=0.11.0
python setup.py install --user
cd ..
```

### 3. 安装其他依赖
```bash
# 安装数值计算库
sudo apt install -y python3-numpy python3-scipy python3-matplotlib
pip install numpy==1.19.5 scipy matplotlib

# 安装图像处理库
sudo apt install -y python3-opencv
pip install opencv-python==4.5.3.56

# 安装其他Python包
pip install Pillow==8.3.2
pip install scikit-image==0.18.3
pip install tqdm==4.62.3
pip install yacs==0.1.8
pip install einops==0.4.1
pip install timm==0.5.4
pip install natsort==8.0.0

# 安装PyWavelets (用于小波变换)
pip install PyWavelets==1.2.0
```

## 模型优化

### 1. 创建模型转换脚本（可选）
```python
# convert_to_tensorrt.py
import torch
import torch.nn as nn
from model.ALICC import ALICC
import numpy as np

# TensorRT相关导入（需要先安装TensorRT）
try:
    import tensorrt as trt
    import pycuda.driver as cuda
    import pycuda.autoinit
    TENSORRT_AVAILABLE = True
    print("TensorRT可用")
except ImportError:
    TENSORRT_AVAILABLE = False
    print("TensorRT不可用，将跳过TensorRT优化")

class ALICEOptimized(nn.Module):
    """优化版本的ALICE模型"""
    def __init__(self, original_model):
        super(ALICEOptimized, self).__init__()
        self.model = original_model
        
    def forward(self, color_img, mono_img):
        # 简化前向传播，只返回主要输出
        with torch.no_grad():
            restored_img, _, _, _ = self.model(color_img, mono_img)
        return restored_img

def convert_to_onnx(model_path, onnx_path):
    """转换模型到ONNX格式"""
    # 加载预训练模型
    model = ALICC(Ch_img=3, Channels=32, state='Test', REF=True, tests=False)
    checkpoint = torch.load(model_path, map_location='cpu')
    model.load_state_dict(checkpoint['model'])
    model.eval()
    
    # 创建优化版本
    optimized_model = ALICEOptimized(model)
    optimized_model.eval()
    
    # 创建示例输入
    color_input = torch.randn(1, 3, 256, 256)
    mono_input = torch.randn(1, 3, 256, 256)
    
    # 导出ONNX
    torch.onnx.export(
        optimized_model,
        (color_input, mono_input),
        onnx_path,
        export_params=True,
        opset_version=11,
        do_constant_folding=True,
        input_names=['color_input', 'mono_input'],
        output_names=['output'],
        dynamic_axes={
            'color_input': {0: 'batch_size', 2: 'height', 3: 'width'},
            'mono_input': {0: 'batch_size', 2: 'height', 3: 'width'},
            'output': {0: 'batch_size', 2: 'height', 3: 'width'}
        }
    )
    print(f"模型已导出到: {onnx_path}")

def build_tensorrt_engine(onnx_path, engine_path, max_batch_size=1):
    """构建TensorRT引擎"""
    TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
    builder = trt.Builder(TRT_LOGGER)
    config = builder.create_builder_config()
    
    # 设置内存池大小 (适合Jetson Nano的4GB内存)
    config.max_workspace_size = 1 << 28  # 256MB
    
    # 启用FP16精度以提高性能
    if builder.platform_has_fast_fp16:
        config.set_flag(trt.BuilderFlag.FP16)
    
    # 解析ONNX模型
    network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
    parser = trt.OnnxParser(network, TRT_LOGGER)
    
    with open(onnx_path, 'rb') as model:
        if not parser.parse(model.read()):
            print('ERROR: Failed to parse the ONNX file.')
            for error in range(parser.num_errors):
                print(parser.get_error(error))
            return None
    
    # 构建引擎
    engine = builder.build_engine(network, config)
    
    # 保存引擎
    with open(engine_path, 'wb') as f:
        f.write(engine.serialize())
    
    print(f"TensorRT引擎已保存到: {engine_path}")
    return engine

if __name__ == "__main__":
    model_path = "checkpoints/Real/model_best.pth"
    onnx_path = "alice_optimized.onnx"
    engine_path = "alice_optimized.trt"
    
    # 转换到ONNX
    convert_to_onnx(model_path, onnx_path)
    
    # 构建TensorRT引擎
    build_tensorrt_engine(onnx_path, engine_path)
```

### 2. 执行模型转换
```bash
# 激活虚拟环境
source alice_env/bin/activate

# 安装ONNX相关包
pip install onnx==1.10.2 onnxruntime==1.9.0

# 执行转换
python convert_to_tensorrt.py
```

## 部署代码

### 1. 创建Jetson推理类
```python
# jetson_inference.py
import cv2
import numpy as np
import torch
import torchvision.transforms.functional as TF
from PIL import Image
import time
import threading
from queue import Queue

class JetsonALICEInference:
    """Jetson Nano上的ALICE模型推理类"""
    
    def __init__(self, model_path, device='cuda', input_size=(256, 256)):
        self.device = device
        self.input_size = input_size
        self.model = self._load_model(model_path)
        self.frame_queue = Queue(maxsize=2)
        
    def _load_model(self, model_path):
        """加载优化后的模型"""
        from model.ALICC import ALICC
        
        model = ALICC(Ch_img=3, Channels=32, state='Test', REF=True, tests=False)
        checkpoint = torch.load(model_path, map_location=self.device)
        model.load_state_dict(checkpoint['model'])
        model.to(self.device)
        model.eval()
        
        # 预热模型
        dummy_color = torch.randn(1, 3, *self.input_size).to(self.device)
        dummy_mono = torch.randn(1, 3, *self.input_size).to(self.device)
        with torch.no_grad():
            _ = model(dummy_color, dummy_mono)
        
        return model
    
    def preprocess_image(self, image):
        """图像预处理"""
        if isinstance(image, np.ndarray):
            image = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        
        # 调整大小到模型输入尺寸
        original_size = image.size
        image = image.resize(self.input_size, Image.BICUBIC)
        
        # 转换为张量
        tensor = TF.to_tensor(image).unsqueeze(0).to(self.device)
        
        return tensor, original_size
    
    def postprocess_output(self, output, original_size):
        """输出后处理"""
        # 调整回原始尺寸
        output = TF.resize(output, original_size[::-1], interpolation=Image.BICUBIC)
        
        # 转换为numpy数组
        output = torch.clamp(output, 0, 1).squeeze(0).permute(1, 2, 0).cpu().numpy()
        output = (output * 255).astype(np.uint8)
        
        # 转换颜色空间
        output = cv2.cvtColor(output, cv2.COLOR_RGB2BGR)
        
        return output
    
    def inference_single(self, color_image, mono_image=None):
        """单张图像推理"""
        start_time = time.time()
        
        # 预处理
        color_tensor, original_size = self.preprocess_image(color_image)
        
        if mono_image is None:
            # 如果没有单色图像，使用彩色图像的灰度版本
            mono_image = cv2.cvtColor(color_image, cv2.COLOR_BGR2GRAY)
            mono_image = cv2.cvtColor(mono_image, cv2.COLOR_GRAY2BGR)
        
        mono_tensor, _ = self.preprocess_image(mono_image)
        
        # 推理
        with torch.no_grad():
            restored_img, _, _, _ = self.model(color_tensor, mono_tensor)
        
        # 后处理
        result = self.postprocess_output(restored_img, original_size)
        
        inference_time = time.time() - start_time
        
        return result, inference_time
    
    def inference_video_stream(self, color_cap, mono_cap=None, output_path=None):
        """视频流推理"""
        if output_path:
            fourcc = cv2.VideoWriter_fourcc(*'XVID')
            fps = color_cap.get(cv2.CAP_PROP_FPS) or 30
            width = int(color_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(color_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
        
        frame_count = 0
        total_time = 0
        
        try:
            while True:
                ret_color, color_frame = color_cap.read()
                if not ret_color:
                    break
                
                mono_frame = None
                if mono_cap:
                    ret_mono, mono_frame = mono_cap.read()
                    if not ret_mono:
                        break
                
                # 推理
                result, inference_time = self.inference_single(color_frame, mono_frame)
                
                frame_count += 1
                total_time += inference_time
                
                # 显示FPS信息
                fps = 1.0 / inference_time if inference_time > 0 else 0
                cv2.putText(result, f'FPS: {fps:.1f}', (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                
                # 显示结果
                cv2.imshow('ALICE Enhanced', result)
                cv2.imshow('Original', color_frame)
                
                # 保存视频
                if output_path:
                    out.write(result)
                
                # 退出条件
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                
        except KeyboardInterrupt:
            print("推理被用户中断")
        
        finally:
            # 清理资源
            color_cap.release()
            if mono_cap:
                mono_cap.release()
            if output_path:
                out.release()
            cv2.destroyAllWindows()
            
            # 打印统计信息
            if frame_count > 0:
                avg_fps = frame_count / total_time
                print(f"处理了 {frame_count} 帧")
                print(f"平均FPS: {avg_fps:.2f}")
                print(f"平均推理时间: {total_time/frame_count*1000:.2f}ms")

# 使用示例
if __name__ == "__main__":
    # 初始化推理器
    inference = JetsonALICEInference("checkpoints/Real/model_best.pth")
    
    # 测试单张图像
    color_img = cv2.imread("test_image.jpg")
    result, inf_time = inference.inference_single(color_img)
    print(f"推理时间: {inf_time*1000:.2f}ms")
    
    # 保存结果
    cv2.imwrite("enhanced_result.jpg", result)
    
    # 测试摄像头实时推理
    # color_cap = cv2.VideoCapture(0)  # USB摄像头
    # inference.inference_video_stream(color_cap, output_path="enhanced_output.avi")
```

### 2. 创建部署脚本
```python
# deploy_alice.py
import argparse
import cv2
import os
import sys
from jetson_inference import JetsonALICEInference

def main():
    parser = argparse.ArgumentParser(description='ALICE模型Jetson Nano部署')
    parser.add_argument('--model', type=str, required=True, help='模型权重路径')
    parser.add_argument('--mode', type=str, choices=['image', 'video', 'camera'], 
                       default='camera', help='推理模式')
    parser.add_argument('--input', type=str, help='输入文件路径')
    parser.add_argument('--output', type=str, help='输出文件路径')
    parser.add_argument('--color_camera', type=int, default=0, help='彩色摄像头ID')
    parser.add_argument('--mono_camera', type=int, help='单色摄像头ID')
    
    args = parser.parse_args()
    
    # 检查模型文件
    if not os.path.exists(args.model):
        print(f"错误: 模型文件不存在: {args.model}")
        sys.exit(1)
    
    # 初始化推理器
    print("正在加载ALICE模型...")
    inference = JetsonALICEInference(args.model)
    print("模型加载完成!")
    
    if args.mode == 'image':
        # 单张图像推理
        if not args.input or not os.path.exists(args.input):
            print("错误: 请提供有效的输入图像路径")
            sys.exit(1)
        
        color_img = cv2.imread(args.input)
        result, inf_time = inference.inference_single(color_img)
        
        output_path = args.output or 'enhanced_' + os.path.basename(args.input)
        cv2.imwrite(output_path, result)
        print(f"推理完成! 时间: {inf_time*1000:.2f}ms, 输出: {output_path}")
        
    elif args.mode == 'video':
        # 视频文件推理
        if not args.input or not os.path.exists(args.input):
            print("错误: 请提供有效的输入视频路径")
            sys.exit(1)
        
        color_cap = cv2.VideoCapture(args.input)
        output_path = args.output or 'enhanced_' + os.path.basename(args.input)
        inference.inference_video_stream(color_cap, output_path=output_path)
        
    elif args.mode == 'camera':
        # 实时摄像头推理
        color_cap = cv2.VideoCapture(args.color_camera)
        mono_cap = None
        
        if args.mono_camera is not None:
            mono_cap = cv2.VideoCapture(args.mono_camera)
        
        print("开始实时推理，按'q'退出...")
        inference.inference_video_stream(color_cap, mono_cap, args.output)

if __name__ == "__main__":
    main()
```

## 性能优化

### 1. 系统级优化
```bash
# 创建性能优化脚本
cat > optimize_jetson.sh << 'EOF'
#!/bin/bash

# 设置最大性能模式
sudo nvpmodel -m 0
sudo jetson_clocks

# 增加交换文件大小
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab

# 优化GPU内存
echo 'options nvidia NVreg_RegistryDwords="RMUseSwapMemory=0x01"' | sudo tee -a /etc/modprobe.d/nvidia.conf

# 设置CPU调度器
echo performance | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor

# 禁用不必要的服务
sudo systemctl disable bluetooth
sudo systemctl disable cups
sudo systemctl disable avahi-daemon

echo "Jetson Nano优化完成!"
EOF

chmod +x optimize_jetson.sh
sudo ./optimize_jetson.sh
```

### 2. 模型量化优化
```python
# quantization.py
import torch
import torch.quantization as quantization
from model.ALICC import ALICC

def quantize_model(model_path, quantized_path):
    """模型量化以减少内存使用"""
    # 加载模型
    model = ALICC(Ch_img=3, Channels=32, state='Test', REF=True, tests=False)
    checkpoint = torch.load(model_path, map_location='cpu')
    model.load_state_dict(checkpoint['model'])
    model.eval()
    
    # 配置量化
    model.qconfig = quantization.get_default_qconfig('fbgemm')
    quantization.prepare(model, inplace=True)
    
    # 校准数据 (使用少量样本)
    dummy_color = torch.randn(1, 3, 256, 256)
    dummy_mono = torch.randn(1, 3, 256, 256)
    
    with torch.no_grad():
        for _ in range(10):  # 校准次数
            model(dummy_color, dummy_mono)
    
    # 转换为量化模型
    quantization.convert(model, inplace=True)
    
    # 保存量化模型
    torch.save({'model': model.state_dict()}, quantized_path)
    print(f"量化模型已保存到: {quantized_path}")

if __name__ == "__main__":
    quantize_model("checkpoints/Real/model_best.pth", "checkpoints/Real/model_quantized.pth")
```

### 3. 内存管理优化
```python
# memory_optimizer.py
import torch
import gc

class MemoryOptimizer:
    """内存优化管理器"""
    
    @staticmethod
    def clear_cache():
        """清理GPU缓存"""
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()
    
    @staticmethod
    def get_memory_usage():
        """获取内存使用情况"""
        if torch.cuda.is_available():
            allocated = torch.cuda.memory_allocated() / 1024**2  # MB
            cached = torch.cuda.memory_reserved() / 1024**2      # MB
            return allocated, cached
        return 0, 0
    
    @staticmethod
    def optimize_for_inference(model):
        """为推理优化模型"""
        model.eval()
        for param in model.parameters():
            param.requires_grad = False
        return model

# 在推理代码中使用
def inference_with_memory_management(model, color_img, mono_img):
    """带内存管理的推理"""
    optimizer = MemoryOptimizer()
    
    try:
        with torch.no_grad():
            result = model(color_img, mono_img)
        return result
    finally:
        optimizer.clear_cache()
```

## 实时推理

### 1. 多线程推理管道
```python
# threaded_inference.py
import threading
import time
from queue import Queue, Empty
import cv2
import torch

class ThreadedInference:
    """多线程推理管道"""
    
    def __init__(self, model_path, max_queue_size=3):
        self.inference_engine = JetsonALICEInference(model_path)
        self.input_queue = Queue(maxsize=max_queue_size)
        self.output_queue = Queue(maxsize=max_queue_size)
        self.running = False
        
    def start(self):
        """启动推理线程"""
        self.running = True
        self.inference_thread = threading.Thread(target=self._inference_worker)
        self.inference_thread.start()
    
    def stop(self):
        """停止推理线程"""
        self.running = False
        if hasattr(self, 'inference_thread'):
            self.inference_thread.join()
    
    def _inference_worker(self):
        """推理工作线程"""
        while self.running:
            try:
                # 获取输入帧
                frame_data = self.input_queue.get(timeout=1.0)
                if frame_data is None:
                    continue
                
                color_frame, mono_frame, timestamp = frame_data
                
                # 执行推理
                result, inf_time = self.inference_engine.inference_single(
                    color_frame, mono_frame)
                
                # 将结果放入输出队列
                if not self.output_queue.full():
                    self.output_queue.put((result, timestamp, inf_time))
                else:
                    # 如果输出队列满了，丢弃最旧的结果
                    try:
                        self.output_queue.get_nowait()
                        self.output_queue.put((result, timestamp, inf_time))
                    except Empty:
                        pass
                        
            except Empty:
                continue
            except Exception as e:
                print(f"推理错误: {e}")
    
    def put_frame(self, color_frame, mono_frame=None):
        """添加帧到推理队列"""
        timestamp = time.time()
        if not self.input_queue.full():
            self.input_queue.put((color_frame, mono_frame, timestamp))
        else:
            # 如果输入队列满了，丢弃最旧的帧
            try:
                self.input_queue.get_nowait()
                self.input_queue.put((color_frame, mono_frame, timestamp))
            except Empty:
                pass
    
    def get_result(self, timeout=1.0):
        """获取推理结果"""
        try:
            return self.output_queue.get(timeout=timeout)
        except Empty:
            return None

# 使用示例
def realtime_demo():
    """实时推理演示"""
    threaded_inference = ThreadedInference("checkpoints/Real/model_best.pth")
    threaded_inference.start()
    
    # 打开摄像头
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 30)
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            # 提交帧进行推理
            threaded_inference.put_frame(frame)
            
            # 获取推理结果
            result_data = threaded_inference.get_result(timeout=0.1)
            if result_data:
                result, timestamp, inf_time = result_data
                fps = 1.0 / inf_time if inf_time > 0 else 0
                
                # 添加FPS信息
                cv2.putText(result, f'FPS: {fps:.1f}', (10, 30),
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                cv2.imshow('Enhanced', result)
            
            # 显示原始帧
            cv2.imshow('Original', frame)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
    finally:
        threaded_inference.stop()
        cap.release()
        cv2.destroyAllWindows()
```

### 2. 创建启动脚本
```bash
# 创建启动脚本
cat > start_alice_inference.sh << 'EOF'
#!/bin/bash

# 设置环境变量
export CUDA_VISIBLE_DEVICES=0
export PYTHONPATH=$PYTHONPATH:/home/$USER/ALICE

# 激活虚拟环境
source alice_env/bin/activate

# 设置性能模式
sudo nvpmodel -m 0
sudo jetson_clocks

# 启动推理
cd /home/$USER/ALICE
python deploy_alice.py --model checkpoints/Real/model_best.pth --mode camera

EOF

chmod +x start_alice_inference.sh
```

## 故障排除

### 1. 常见问题及解决方案

#### 内存不足
```bash
# 增加交换文件
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# 减少批处理大小
# 在代码中设置batch_size=1
```

#### CUDA内存错误
```python
# 在推理前清理内存
torch.cuda.empty_cache()

# 使用内存映射加载模型
checkpoint = torch.load(model_path, map_location='cpu')

# 启用内存优化
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.deterministic = False
```

#### 推理速度慢
```python
# 使用半精度推理
model.half()
input_tensor = input_tensor.half()

# 禁用梯度计算
with torch.no_grad():
    output = model(input_tensor)
```

### 2. 性能监控脚本
```python
# monitor_performance.py
import psutil
import GPUtil
import time
import threading

class PerformanceMonitor:
    """性能监控器"""
    
    def __init__(self, log_interval=5):
        self.log_interval = log_interval
        self.monitoring = False
        
    def start_monitoring(self):
        """开始监控"""
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop)
        self.monitor_thread.start()
        
    def stop_monitoring(self):
        """停止监控"""
        self.monitoring = False
        if hasattr(self, 'monitor_thread'):
            self.monitor_thread.join()
    
    def _monitor_loop(self):
        """监控循环"""
        while self.monitoring:
            # CPU使用率
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # 内存使用率
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # GPU使用率 (如果可用)
            try:
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]
                    gpu_util = gpu.load * 100
                    gpu_memory = gpu.memoryUtil * 100
                else:
                    gpu_util = 0
                    gpu_memory = 0
            except:
                gpu_util = 0
                gpu_memory = 0
            
            # 温度
            try:
                temps = psutil.sensors_temperatures()
                cpu_temp = temps['coretemp'][0].current if 'coretemp' in temps else 0
            except:
                cpu_temp = 0
            
            print(f"CPU: {cpu_percent:.1f}% | "
                  f"内存: {memory_percent:.1f}% | "
                  f"GPU: {gpu_util:.1f}% | "
                  f"GPU内存: {gpu_memory:.1f}% | "
                  f"温度: {cpu_temp:.1f}°C")
            
            time.sleep(self.log_interval)

# 使用示例
if __name__ == "__main__":
    monitor = PerformanceMonitor(log_interval=2)
    monitor.start_monitoring()
    
    try:
        # 运行你的推理代码
        time.sleep(60)  # 监控60秒
    except KeyboardInterrupt:
        pass
    finally:
        monitor.stop_monitoring()
```

### 3. 自动部署脚本
```bash
# auto_deploy.sh - 完整的自动部署脚本
#!/bin/bash

echo "=== ALICE模型Jetson Nano自动部署脚本 ==="

# 检查是否在Jetson设备上运行
if ! command -v nvpmodel &> /dev/null; then
    echo "错误: 此脚本只能在Jetson设备上运行"
    exit 1
fi

# 设置变量
PROJECT_DIR="/home/$USER/ALICE"
VENV_DIR="$PROJECT_DIR/alice_env"
MODEL_URL="https://github.com/your-repo/ALICE/releases/download/v1.0/model_best.pth"

# 创建项目目录
echo "创建项目目录..."
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

# 克隆代码仓库
echo "下载ALICE代码..."
if [ ! -d ".git" ]; then
    git clone https://github.com/your-repo/ALICE.git .
fi

# 创建虚拟环境
echo "创建Python虚拟环境..."
python3 -m venv $VENV_DIR
source $VENV_DIR/bin/activate

# 升级pip
pip install --upgrade pip

# 安装依赖
echo "安装Python依赖..."
pip install torch==1.10.0 torchvision==0.11.0 -f https://download.pytorch.org/whl/torch_stable.html
pip install opencv-python Pillow scikit-image tqdm yacs einops timm natsort PyWavelets

# 下载预训练模型
echo "下载预训练模型..."
mkdir -p checkpoints/Real
if [ ! -f "checkpoints/Real/model_best.pth" ]; then
    wget -O checkpoints/Real/model_best.pth $MODEL_URL
fi

# 设置系统性能
echo "优化系统性能..."
sudo nvpmodel -m 0
sudo jetson_clocks

# 创建启动脚本
cat > start_inference.sh << 'EOL'
#!/bin/bash
cd /home/$USER/ALICE
source alice_env/bin/activate
python deploy_alice.py --model checkpoints/Real/model_best.pth --mode camera
EOL

chmod +x start_inference.sh

# 创建桌面快捷方式
cat > ~/Desktop/ALICE_Inference.desktop << 'EOL'
[Desktop Entry]
Version=1.0
Type=Application
Name=ALICE Inference
Comment=Start ALICE low-light image enhancement
Exec=/home/$USER/ALICE/start_inference.sh
Icon=applications-graphics
Terminal=true
Categories=Graphics;Photography;
EOL

chmod +x ~/Desktop/ALICE_Inference.desktop

echo "=== 部署完成! ==="
echo "使用方法:"
echo "1. 运行: ./start_inference.sh"
echo "2. 或双击桌面上的 ALICE_Inference 图标"
echo "3. 按 'q' 键退出推理"
echo ""
echo "注意事项:"
echo "- 确保摄像头已连接"
echo "- 首次运行可能需要几秒钟加载模型"
echo "- 推理FPS取决于输入图像分辨率"
```

## 总结

本部署指南提供了将ALICE模型完整部署到Jetson Nano的详细步骤，包括：

1. **系统准备**: JetPack安装和基础配置
2. **环境配置**: Python环境和依赖库安装
3. **模型优化**: ONNX转换、TensorRT优化、量化等
4. **部署实现**: 推理类设计和实时处理管道
5. **性能优化**: 内存管理、多线程处理、系统调优
6. **故障排除**: 常见问题解决方案和性能监控

通过本指南，您可以在Jetson Nano上成功部署ALICE模型，实现实时的低光照图像增强处理。根据具体需求，可以进一步调整模型参数和优化策略以获得最佳性能。 