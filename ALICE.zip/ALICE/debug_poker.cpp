#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>

using namespace std;

class PokerWeightCalculator {
private:
    map<string, int> cardToValue;
    vector<int> cardCounts;
    bool hasJ1, hasJ2;
    
    void initCardMapping() {
        string values[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        for (int i = 0; i < 13; i++) {
            cardToValue[values[i]] = i;
        }
    }
    
    void parseCards(vector<string>& cards) {
        cardCounts.assign(13, 0);
        hasJ1 = hasJ2 = false;
        
        cout << "解析手牌:" << endl;
        for (string& card : cards) {
            cout << "处理牌: " << card << endl;
            if (card == "J1") {
                hasJ1 = true;
                cout << "  -> 大王" << endl;
            } else if (card == "J2") {
                hasJ2 = true;
                cout << "  -> 小王" << endl;
            } else {
                string value;
                if (card.length() == 3 && card.substr(1, 2) == "10") {
                    value = "10";
                } else {
                    value = card.substr(1);
                }
                cout << "  -> 点数: " << value << " (索引: " << cardToValue[value] << ")" << endl;
                cardCounts[cardToValue[value]]++;
            }
        }
        
        cout << "\n点数统计:" << endl;
        string names[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
        for (int i = 0; i < 13; i++) {
            if (cardCounts[i] > 0) {
                cout << names[i] << ": " << cardCounts[i] << "张" << endl;
            }
        }
        cout << "大王: " << (hasJ1 ? "有" : "无") << ", 小王: " << (hasJ2 ? "有" : "无") << endl;
    }
    
    bool canFormStraight(int start, const vector<int>& counts) {
        if (start > 8) return false;
        for (int i = start; i < start + 5; i++) {
            if (counts[i] == 0) return false;
        }
        return true;
    }
    
    int calculateMaxWeight(vector<int> counts, bool j1, bool j2, int depth = 0) {
        string indent(depth * 2, ' ');
        cout << indent << "计算权重 (深度 " << depth << ")" << endl;
        
        int maxWeight = 0;
        
        // 检查终止条件
        bool hasCards = false;
        for (int i = 0; i < 13; i++) {
            if (counts[i] > 0) {
                hasCards = true;
                break;
            }
        }
        if (!hasCards && !j1 && !j2) {
            cout << indent << "没有牌了，返回0" << endl;
            return 0;
        }
        
        // 尝试双王
        if (j1 && j2) {
            cout << indent << "尝试双王" << endl;
            maxWeight = max(maxWeight, 5 + calculateMaxWeight(counts, false, false, depth + 1));
        }
        
        // 尝试单顺
        for (int start = 0; start <= 8; start++) {
            if (canFormStraight(start, counts)) {
                string names[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
                cout << indent << "尝试单顺: " << names[start] << "-" << names[start+4] << endl;
                vector<int> newCounts = counts;
                for (int i = start; i < start + 5; i++) {
                    newCounts[i]--;
                }
                maxWeight = max(maxWeight, 3 + calculateMaxWeight(newCounts, j1, j2, depth + 1));
            }
        }
        
        // 尝试对牌
        for (int i = 0; i < 13; i++) {
            if (counts[i] >= 2) {
                string names[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
                cout << indent << "尝试对牌: " << names[i] << endl;
                vector<int> newCounts = counts;
                newCounts[i] -= 2;
                maxWeight = max(maxWeight, 2 + calculateMaxWeight(newCounts, j1, j2, depth + 1));
            }
        }
        
        cout << indent << "当前最大权重: " << maxWeight << endl;
        return maxWeight;
    }
    
public:
    PokerWeightCalculator() {
        initCardMapping();
    }
    
    int solve(vector<string>& cards) {
        parseCards(cards);
        cout << "\n开始计算最大权重:" << endl;
        return calculateMaxWeight(cardCounts, hasJ1, hasJ2);
    }
};

int main() {
    int n;
    cin >> n;
    
    vector<string> cards(n);
    for (int i = 0; i < n; i++) {
        cin >> cards[i];
    }
    
    PokerWeightCalculator calculator;
    int result = calculator.solve(cards);
    cout << "\n最终结果: " << result << endl;
    
    return 0;
} 