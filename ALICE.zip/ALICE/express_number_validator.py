def validate_express_number(express_number):
    """
    验证和修复快递单号
    
    Args:
        express_number (str): 待校验的快递单号
        
    Returns:
        str: 修复后的单号或"Invalid"
    """
    # 检查长度是否为9位
    if len(express_number) != 9:
        return "Invalid"
    
    # 提取前8位和校验位
    prefix_8 = express_number[:8]
    check_digit = express_number[8]
    
    # 检查前2位是否为大写字母
    if not (prefix_8[0].isupper() and prefix_8[0].isalpha() and 
            prefix_8[1].isupper() and prefix_8[1].isalpha()):
        return "Invalid"
    
    # 检查第3-8位是否为数字
    if not prefix_8[2:8].isdigit():
        return "Invalid"
    
    # 计算正确的校验位
    ascii_sum = sum(ord(char) for char in prefix_8)
    correct_check_digit = chr((ascii_sum % 26) + ord('A'))
    
    # 构造正确的单号
    correct_number = prefix_8 + correct_check_digit
    
    return correct_number


def main():
    """主函数，处理输入输出"""
    express_number = input().strip()
    result = validate_express_number(express_number)
    print(result)


if __name__ == "__main__":
    main() 