from fish_game import solve_fish_game

# 测试示例
n = 4
a = [3, 2, 4, 2]
result = solve_fish_game(n, a)
print(f"输入: {a}")
print(f"输出: {result}")
print(f"期望: [2, 1, 2, 1]")
print(f"正确: {result == [2, 1, 2, 1]}")

# 测试其他情况
test_cases = [
    ([3, 2], [-1, 1]),
    ([2, 3, 1], [1, -1, 1]),
    ([2, 2, 2], [-1, -1, -1]),
    ([1, 2, 3], [-1, -1, -1])
]

for i, (input_data, expected) in enumerate(test_cases):
    result = solve_fish_game(len(input_data), input_data)
    print(f"测试{i+1}: {input_data} -> {result} (期望: {expected}) {'✓' if result == expected else '✗'}") 