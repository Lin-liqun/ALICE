from magic_academy import solve_magic_academy

def test_magic_academy():
    """测试魔法学院问题"""
    
    # 测试示例1
    print("=== 测试示例1 ===")
    n1, m1, M1 = 1, 1, 5
    power1 = [10]
    mana1 = [5]
    bonus1 = [2]
    
    result1 = solve_magic_academy(n1, m1, M1, power1, mana1, bonus1)
    print(f"输入: n={n1}, m={m1}, M={M1}")
    print(f"power={power1}, mana={mana1}, bonus={bonus1}")
    print(f"结果: {result1} (期望: 0)")
    print(f"说明: 实际消耗 = 5×2 = 10 > 5，无法学习")
    print()
    
    # 测试示例2：可以学习的情况
    print("=== 测试示例2 ===")
    n2, m2, M2 = 2, 2, 20
    power2 = [10, 5]
    mana2 = [5, 3]
    bonus2 = [2, 1]
    
    result2 = solve_magic_academy(n2, m2, M2, power2, mana2, bonus2)
    print(f"输入: n={n2}, m={m2}, M={M2}")
    print(f"power={power2}, mana={mana2}, bonus={bonus2}")
    print(f"结果: {result2}")
    print("分析:")
    print("  课程1在楼层1: 强度=10×2=20, 消耗=5×2=10")
    print("  课程1在楼层2: 强度=10×1=10, 消耗=5×1=5")
    print("  课程2在楼层1: 强度=5×2=10, 消耗=3×2=6")
    print("  课程2在楼层2: 强度=5×1=5, 消耗=3×1=3")
    print()
    
    # 测试示例3：切换楼层成本
    print("=== 测试示例3 ===")
    n3, m3, M3 = 2, 3, 15
    power3 = [6, 4]
    mana3 = [2, 2]
    bonus3 = [1, 2, 3]
    
    result3 = solve_magic_academy(n3, m3, M3, power3, mana3, bonus3)
    print(f"输入: n={n3}, m={m3}, M={M3}")
    print(f"power={power3}, mana={mana3}, bonus={bonus3}")
    print(f"结果: {result3}")
    print("分析切换成本:")
    print("  从楼层1到楼层3: 切换成本 = 3-1 = 2")
    print("  从楼层3到楼层1: 切换成本 = 0（高到低无成本）")
    print()
    
    # 测试示例4：单门课程，多楼层选择
    print("=== 测试示例4 ===")
    n4, m4, M4 = 1, 3, 10
    power4 = [5]
    mana4 = [4]
    bonus4 = [1, 2, 3]
    
    result4 = solve_magic_academy(n4, m4, M4, power4, mana4, bonus4)
    print(f"输入: n={n4}, m={m4}, M={M4}")
    print(f"power={power4}, mana={mana4}, bonus={bonus4}")
    print(f"结果: {result4}")
    print("楼层选择:")
    print("  楼层1: 强度=5×1=5, 消耗=4×1=4")
    print("  楼层2: 强度=5×2=10, 消耗=4×2=8")
    print("  楼层3: 强度=5×3=15, 消耗=4×3=12 > 10（超出限制）")
    print("  最优选择：楼层2")


if __name__ == "__main__":
    test_magic_academy() 