import numpy as np

def generate_data(noise, real):
    # 将输入列表转换为numpy数组
    noise_array = np.array(noise)
    real_array = np.array(real)
    
    # 生成假数据：真实数据 + 随机噪声
    fake_data = real_array + noise_array
    
    return fake_data

if __name__ == '__main__':
    np.random.seed(42)
    n, d = map(int, input().split())
    noise = [list(map(float, input().split())) for _ in range(n)]
    real_data = [list(map(float, input().split())) for _ in range(n)]
    data = generate_data(noise, real_data)
    for row in data:
        print(' '.join(str(round(row[i], 2)) for i in range(d))) 