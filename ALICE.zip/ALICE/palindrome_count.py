def is_palindrome(s):
    """
    判断字符串是否为回文
    """
    return s == s[::-1]

def count_palindrome_substrings(n, m, s):
    """
    计算长度为m的回文子串数量
    """
    count = 0
    
    # 遍历所有长度为m的子串
    for i in range(n - m + 1):
        substring = s[i:i + m]
        if is_palindrome(substring):
            count += 1
    
    return count

def main():
    # 读取输入
    n, m = map(int, input().split())
    s = input().strip()
    
    # 计算回文子串数量
    result = count_palindrome_substrings(n, m, s)
    
    # 输出结果
    print(result)

if __name__ == "__main__":
    main() 