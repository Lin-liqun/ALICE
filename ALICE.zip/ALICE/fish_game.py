def solve_fish_game(n, a):
    """
    解决大鱼吃小鱼游戏问题
    使用递归搜索所有可能的游戏状态
    """
    memo = {}
    
    def dfs(fish_list):
        """
        返回当前状态下每条原始鱼被吃掉的最少步数
        fish_list: [(原始索引, 当前血量), ...]
        """
        if len(fish_list) <= 1:
            return {}
        
        state_key = tuple(fish_list)
        if state_key in memo:
            return memo[state_key]
        
        result = {}
        
        # 尝试所有可能的吃鱼操作
        for i in range(len(fish_list)):
            orig_idx_i, blood_i = fish_list[i]
            
            # 尝试吃左邻居
            if i > 0:
                orig_idx_j, blood_j = fish_list[i-1]
                if blood_i > blood_j:
                    new_fish = fish_list[:i-1] + [(orig_idx_i, blood_i + blood_j)] + fish_list[i+1:]
                    sub_result = dfs(new_fish)
                    
                    if orig_idx_j not in result or result[orig_idx_j] > 1:
                        result[orig_idx_j] = 1
                    
                    for fish_idx, steps in sub_result.items():
                        if fish_idx not in result or result[fish_idx] > steps + 1:
                            result[fish_idx] = steps + 1
            
            # 尝试吃右邻居
            if i < len(fish_list) - 1:
                orig_idx_j, blood_j = fish_list[i+1]
                if blood_i > blood_j:
                    new_fish = fish_list[:i] + [(orig_idx_i, blood_i + blood_j)] + fish_list[i+2:]
                    sub_result = dfs(new_fish)
                    
                    if orig_idx_j not in result or result[orig_idx_j] > 1:
                        result[orig_idx_j] = 1
                    
                    for fish_idx, steps in sub_result.items():
                        if fish_idx not in result or result[fish_idx] > steps + 1:
                            result[fish_idx] = steps + 1
        
        memo[state_key] = result
        return result
    
    # 构建初始状态和最终答案
    initial_fish = [(i, a[i]) for i in range(n)]
    final_result = dfs(initial_fish)
    
    return [final_result.get(i, -1) for i in range(n)]


def main():
    """ACM模式主函数"""
    n = int(input().strip())
    a = list(map(int, input().strip().split()))
    
    result = solve_fish_game(n, a)
    print(' '.join(map(str, result)))


if __name__ == "__main__":
    main() 