import numpy as np
import pandas as pd

def simple_generator():
    """
    简单的生成器实现：将真实数据与随机噪声相加生成假数据
    """
    # 读取输入
    line = input().strip().split()
    N, D = int(line[0]), int(line[1])
    
    # 读取随机噪声数据
    noise_data = []
    for i in range(N):
        noise_row = list(map(float, input().strip().split()))
        noise_data.append(noise_row)
    
    # 读取真实数据
    real_data = []
    for i in range(N):
        real_row = list(map(float, input().strip().split()))
        real_data.append(real_row)
    
    # 转换为numpy数组便于计算
    noise_array = np.array(noise_data)
    real_array = np.array(real_data)
    
    # 生成假数据：真实数据 + 随机噪声
    fake_data = real_array + noise_array
    
    # 输出结果，保留两位小数
    for row in fake_data:
        formatted_row = [f"{value:.2f}" for value in row]
        print(" ".join(formatted_row))

if __name__ == "__main__":
    simple_generator() 