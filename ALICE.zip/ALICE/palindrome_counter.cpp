#include <iostream>
#include <string>
using namespace std;

// 检查字符串是否为回文
bool isPalindrome(const string& s, int start, int length) {
    int left = start;
    int right = start + length - 1;
    
    while (left < right) {
        if (s[left] != s[right]) {
            return false;
        }
        left++;
        right--;
    }
    return true;
}

int main() {
    int n, m;
    cin >> n >> m;
    
    string s;
    cin >> s;
    
    int count = 0;
    
    // 遍历所有长度为m的子串
    for (int i = 0; i <= n - m; i++) {
        if (isPalindrome(s, i, m)) {
            count++;
        }
    }
    
    cout << count << endl;
    
    return 0;
} 