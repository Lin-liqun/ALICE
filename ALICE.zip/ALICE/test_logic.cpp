#include <iostream>
#include <vector>
#include <string>

using namespace std;

// 复制主程序的逻辑检查函数
bool isConsistent(vector<bool>& playPhone, vector<bool>& isLiar) {
    // a的话：我可没玩手机 (a没玩手机)
    bool aStatement = !playPhone[0];  // a说自己没玩手机
    if (isLiar[0] == aStatement) {  // 如果a说谎，他的话应该是假的；如果不说谎，话应该是真的
        return false;
    }
    
    // b的话：c玩手机了
    bool bStatement = playPhone[2];  // b说c玩手机
    if (isLiar[1] == bStatement) {  // 如果b说谎，他的话应该是假的；如果不说谎，话应该是真的
        return false;
    }
    
    // c的话：玩手机的肯定是d (只有d玩手机)
    bool cStatement = playPhone[3] && !playPhone[0] && !playPhone[1] && !playPhone[2];  // 只有d玩手机
    if (isLiar[2] == cStatement) {  // 如果c说谎，他的话应该是假的；如果不说谎，话应该是真的
        return false;
    }
    
    // d的话：c胡说 (c说的是假话)
    bool dStatement = isLiar[2];  // d说c说假话
    if (isLiar[3] == dStatement) {  // 如果d说谎，他的话应该是假的；如果不说谎，话应该是真的
        return false;
    }
    
    return true;
}

void testCase(vector<bool> playPhone, vector<bool> isLiar, string desc) {
    cout << "测试: " << desc << endl;
    cout << "玩手机: ";
    for (int i = 0; i < 4; i++) {
        if (playPhone[i]) cout << char('a' + i) << " ";
    }
    cout << endl;
    cout << "说谎: ";
    for (int i = 0; i < 4; i++) {
        if (isLiar[i]) cout << char('a' + i) << " ";
    }
    cout << endl;
    cout << "一致性: " << (isConsistent(playPhone, isLiar) ? "是" : "否") << endl;
    cout << "---" << endl;
}

int main() {
    // 测试一些简单情况
    vector<bool> playPhone, isLiar;
    
    // 测试1: 只有d玩手机，c说真话
    playPhone = {false, false, false, true};
    isLiar = {true, true, false, true};
    testCase(playPhone, isLiar, "只有d玩手机，c说真话");
    
    // 测试2: 没人玩手机
    playPhone = {false, false, false, false};
    isLiar = {false, true, true, false};
    testCase(playPhone, isLiar, "没人玩手机");
    
    return 0;
} 