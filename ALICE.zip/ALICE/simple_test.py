# 简单测试扑克牌权重计算
def test_example():
    # 示例：C2, D3, S4, C5, C6, C4
    # 应该有：2(1张), 3(1张), 4(2张), 5(1张), 6(1张)
    # 可以组成：单顺 2,3,4,5,6 (权重3) 或者 一对4 (权重2)
    # 最大权重应该是3
    
    cards = ['C2', 'D3', 'S4', 'C5', 'C6', 'C4']
    
    # 统计点数
    counts = [0] * 13  # 2-A对应0-12
    card_values = {'2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, '9': 7, '10': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12}
    
    for card in cards:
        if card not in ['J1', 'J2']:
            if len(card) == 3 and card[1:3] == '10':
                value = '10'
            else:
                value = card[1:]
            counts[card_values[value]] += 1
    
    print("点数统计:")
    values_names = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
    for i, count in enumerate(counts):
        if count > 0:
            print(f"{values_names[i]}: {count}张")
    
    # 检查单顺 2,3,4,5,6 (索引0,1,2,3,4)
    can_straight_23456 = all(counts[i] > 0 for i in range(0, 5))
    print(f"\n可以组成单顺2,3,4,5,6: {can_straight_23456}")
    
    # 检查对4
    can_pair_4 = counts[2] >= 2  # 4对应索引2
    print(f"可以组成对4: {can_pair_4}")
    
    # 计算权重
    if can_straight_23456:
        print("选择单顺，权重为3")
        return 3
    elif can_pair_4:
        print("选择对4，权重为2")
        return 2
    else:
        print("只能是单牌，权重为0")
        return 0

result = test_example()
print(f"\n最终结果: {result}") 