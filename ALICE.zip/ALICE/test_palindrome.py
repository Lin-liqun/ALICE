import io
import sys

def test_palindrome():
    """测试回文子串计算"""
    
    # 测试用例1：题目示例
    print("=== 测试1: 题目示例 ===")
    test_input1 = "5 3\nababa"
    expected1 = "2"
    
    sys.stdin = io.StringIO(test_input1)
    captured_output = io.StringIO()
    sys.stdout = captured_output
    
    from palindrome_count import main
    main()
    
    sys.stdin = sys.__stdin__
    sys.stdout = sys.__stdout__
    
    result1 = captured_output.getvalue().strip()
    
    print(f"输入: {test_input1.replace(chr(10), ' | ')}")
    print(f"期望: {expected1}")
    print(f"实际: {result1}")
    print(f"结果: {'✓ 通过' if result1 == expected1 else '✗ 失败'}")
    
    # 手动验证
    s = "ababa"
    substrings = []
    for i in range(3):  # 5-3+1 = 3个子串
        sub = s[i:i+3]
        substrings.append(sub)
        is_pal = sub == sub[::-1]
        print(f"子串 {i+1}: '{sub}' -> {'回文' if is_pal else '非回文'}")
    
    print()
    
    # 测试用例2：全部是回文
    print("=== 测试2: 全部回文 ===")
    test_input2 = "4 2\naaaa"
    
    sys.stdin = io.StringIO(test_input2)
    captured_output = io.StringIO()
    sys.stdout = captured_output
    
    main()
    
    sys.stdin = sys.__stdin__
    sys.stdout = sys.__stdout__
    
    result2 = captured_output.getvalue().strip()
    print(f"输入: aaaa, 长度2")
    print(f"子串: aa, aa, aa (3个都是回文)")
    print(f"结果: {result2}")
    print()
    
    # 测试用例3：没有回文
    print("=== 测试3: 无回文 ===")
    test_input3 = "4 3\nabcd"
    
    sys.stdin = io.StringIO(test_input3)
    captured_output = io.StringIO()
    sys.stdout = captured_output
    
    main()
    
    sys.stdin = sys.__stdin__
    sys.stdout = sys.__stdout__
    
    result3 = captured_output.getvalue().strip()
    print(f"输入: abcd, 长度3")
    print(f"子串: abc, bcd (都不是回文)")
    print(f"结果: {result3}")
    print()
    
    # 测试用例4：单字符（总是回文）
    print("=== 测试4: 单字符 ===")
    test_input4 = "5 1\nabcde"
    
    sys.stdin = io.StringIO(test_input4)
    captured_output = io.StringIO()
    sys.stdout = captured_output
    
    main()
    
    sys.stdin = sys.__stdin__
    sys.stdout = sys.__stdout__
    
    result4 = captured_output.getvalue().strip()
    print(f"输入: abcde, 长度1")
    print(f"单字符总是回文，共5个")
    print(f"结果: {result4}")

if __name__ == "__main__":
    test_palindrome() 