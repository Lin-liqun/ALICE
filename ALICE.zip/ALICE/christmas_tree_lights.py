def solve_christmas_tree_lights(n, initial, target):
    """
    解决二叉树彩灯控制问题 - 最终优化版本
    
    时间复杂度: O(n)
    空间复杂度: O(n)
    
    Args:
        n: 数组大小
        initial: 初始状态数组
        target: 目标状态数组
    
    Returns:
        int: 最少点击次数
    """
    if n == 0:
        return 0
    
    # 使用差分数组记录点击影响
    effect = [0] * n
    total_clicks = 0
    
    # 从前往后处理每个节点
    for i in range(n):
        if initial[i] == 0:  # 跳过没有彩灯的节点
            continue
        
        # 计算当前节点的实际颜色（原始颜色 + 累积影响）
        current_color = (initial[i] + effect[i] - 1) % 5 + 1
        
        # 计算需要的点击次数
        need_clicks = (target[i] - current_color) % 5
        total_clicks += need_clicks
        
        # 如果需要点击，批量更新子树影响
        if need_clicks > 0:
            # 使用层次遍历批量更新，避免递归开销
            queue = [i]
            while queue:
                node = queue.pop(0)
                left = 2 * node + 1
                right = 2 * node + 2
                
                if left < n:
                    effect[left] += need_clicks
                    queue.append(left)
                
                if right < n:
                    effect[right] += need_clicks
                    queue.append(right)
    
    return total_clicks


def main():
    """ACM模式主函数"""
    # 读取输入
    n = int(input().strip())
    initial = list(map(int, input().strip().split()))
    target = list(map(int, input().strip().split()))
    
    # 解决问题并输出结果
    result = solve_christmas_tree_lights(n, initial, target)
    print(result)


if __name__ == "__main__":
    main() 