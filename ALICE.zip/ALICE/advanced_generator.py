import numpy as np
import pandas as pd
from typing import Tuple, List
import sys

class SimpleGANGenerator:
    """
    简单的GAN生成器类
    实现基本的数据生成功能：真实数据 + 随机噪声 = 假数据
    """
    
    def __init__(self):
        self.noise_data = None
        self.real_data = None
        self.fake_data = None
    
    def read_input(self) -> Tuple[int, int]:
        """
        读取输入数据
        返回: (样本数量N, 特征数量D)
        """
        line = input().strip().split()
        N, D = int(line[0]), int(line[1])
        
        # 读取随机噪声数据
        noise_data = []
        for i in range(N):
            noise_row = list(map(float, input().strip().split()))
            if len(noise_row) != D:
                raise ValueError(f"噪声数据第{i+1}行特征数量不匹配，期望{D}个，实际{len(noise_row)}个")
            noise_data.append(noise_row)
        
        # 读取真实数据
        real_data = []
        for i in range(N):
            real_row = list(map(float, input().strip().split()))
            if len(real_row) != D:
                raise ValueError(f"真实数据第{i+1}行特征数量不匹配，期望{D}个，实际{len(real_row)}个")
            real_data.append(real_row)
        
        self.noise_data = np.array(noise_data)
        self.real_data = np.array(real_data)
        
        return N, D
    
    def generate_fake_data(self) -> np.ndarray:
        """
        生成假数据：真实数据 + 随机噪声
        """
        if self.noise_data is None or self.real_data is None:
            raise ValueError("请先读取输入数据")
        
        self.fake_data = self.real_data + self.noise_data
        return self.fake_data
    
    def format_output(self, decimal_places: int = 2) -> List[str]:
        """
        格式化输出数据
        """
        if self.fake_data is None:
            raise ValueError("请先生成假数据")
        
        formatted_rows = []
        for row in self.fake_data:
            formatted_row = [f"{value:.{decimal_places}f}" for value in row]
            formatted_rows.append(" ".join(formatted_row))
        
        return formatted_rows
    
    def print_results(self, decimal_places: int = 2):
        """
        打印结果
        """
        formatted_output = self.format_output(decimal_places)
        for row in formatted_output:
            print(row)
    
    def get_statistics(self) -> dict:
        """
        获取数据统计信息
        """
        if self.fake_data is None:
            return {}
        
        return {
            'shape': self.fake_data.shape,
            'mean': np.mean(self.fake_data, axis=0),
            'std': np.std(self.fake_data, axis=0),
            'min': np.min(self.fake_data, axis=0),
            'max': np.max(self.fake_data, axis=0)
        }

def simple_generator():
    """
    简单生成器函数 - 兼容原始接口
    """
    try:
        generator = SimpleGANGenerator()
        N, D = generator.read_input()
        generator.generate_fake_data()
        generator.print_results()
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)

def advanced_generator_with_stats():
    """
    带统计信息的高级生成器
    """
    try:
        generator = SimpleGANGenerator()
        N, D = generator.read_input()
        generator.generate_fake_data()
        
        # 输出结果
        generator.print_results()
        
        # 输出统计信息到stderr（不影响主要输出）
        stats = generator.get_statistics()
        print(f"\n--- 统计信息 ---", file=sys.stderr)
        print(f"数据形状: {stats['shape']}", file=sys.stderr)
        print(f"均值: {stats['mean']}", file=sys.stderr)
        print(f"标准差: {stats['std']}", file=sys.stderr)
        print(f"最小值: {stats['min']}", file=sys.stderr)
        print(f"最大值: {stats['max']}", file=sys.stderr)
        
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    # 根据命令行参数选择运行模式
    if len(sys.argv) > 1 and sys.argv[1] == "--stats":
        advanced_generator_with_stats()
    else:
        simple_generator() 