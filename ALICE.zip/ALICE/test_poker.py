from poker_weight import PokerWeightCalculator

# 测试示例
cards = ['C2', 'D3', 'S4', 'C5', 'C6', 'C4']
calculator = PokerWeightCalculator()

# 调试解析过程
counts, has_j1, has_j2 = calculator.parse_cards(cards)
print(f"Card counts: {counts}")
print(f"Has J1: {has_j1}, Has J2: {has_j2}")

# 检查各点数
for i, count in enumerate(counts):
    if count > 0:
        values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
        print(f"点数 {values[i]}: {count}张")

# 检查可能的牌型
print("\n检查可能的牌型：")

# 检查单顺
for start in range(9):
    if calculator.can_form_straight(start, counts):
        values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
        straight = [values[i] for i in range(start, start + 5)]
        print(f"可以组成单顺: {straight}")

# 检查对牌
for i, count in enumerate(counts):
    if count >= 2:
        values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
        print(f"可以组成对牌: {values[i]}")

result = calculator.solve(cards)
print(f"\n最大权重: {result}") 