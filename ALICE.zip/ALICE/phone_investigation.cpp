#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

// 检查给定的玩手机情况和说假话人数是否一致
bool checkConsistency(vector<bool> playPhone, int x) {
    // a的话：我可没玩手机 (a没玩手机)
    bool a_statement = !playPhone[0];
    
    // b的话：c玩手机了 (c玩手机)
    bool b_statement = playPhone[2];
    
    // c的话：玩手机的肯定是d (d玩手机)
    bool c_statement = playPhone[3];
    
    // d的话：c胡说 (c的话是假的，即d没玩手机)
    bool d_statement = !playPhone[3];
    
    // 统计说假话的人数
    int liars = 0;
    if (!a_statement) liars++; // a说假话
    if (!b_statement) liars++; // b说假话
    if (!c_statement) liars++; // c说假话
    if (!d_statement) liars++; // d说假话
    
    return liars == x;
}

vector<string> solve(int x) {
    vector<string> result;
    bool found = false;
    
    // 枚举所有可能的玩手机情况 (2^4 = 16种)
    for (int mask = 0; mask < 16; mask++) {
        vector<bool> playPhone(4);
        playPhone[0] = (mask & 1) != 0;  // a
        playPhone[1] = (mask & 2) != 0;  // b
        playPhone[2] = (mask & 4) != 0;  // c
        playPhone[3] = (mask & 8) != 0;  // d
        
        if (checkConsistency(playPhone, x)) {
            // 找到一致的情况，记录玩手机的学生
            vector<string> current;
            if (playPhone[0]) current.push_back("a");
            if (playPhone[1]) current.push_back("b");
            if (playPhone[2]) current.push_back("c");
            if (playPhone[3]) current.push_back("d");
            
            if (!found) {
                result = current;
                found = true;
            }
            // 如果有多个解，选择字典序最小的
            else if (current < result) {
                result = current;
            }
        }
    }
    
    return result;
}

int main() {
    int x;
    cin >> x;
    
    vector<string> result = solve(x);
    
    // 输出格式：['name1','name2',...]
    cout << "[";
    for (int i = 0; i < result.size(); i++) {
        if (i > 0) cout << ",";
        cout << "'" << result[i] << "'";
    }
    cout << "]" << endl;
    
    return 0;
} 