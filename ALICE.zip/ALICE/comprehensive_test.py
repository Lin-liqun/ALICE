import numpy as np
import io
import sys
import os

def test_single_sample():
    """测试单个样本的情况"""
    print("=== 测试1: 单个样本 ===")
    
    test_input = """1 5
-0.04 -0.75 0.3 0.36 -0.07
0.5 -0.14 0.65 1.52 -0.23"""
    
    expected_output = "0.46 -0.89 0.95 1.88 -0.30"
    
    sys.stdin = io.StringIO(test_input)
    captured_output = io.StringIO()
    sys.stdout = captured_output
    
    from generator_gan import simple_generator
    simple_generator()
    
    sys.stdin = sys.__stdin__
    sys.stdout = sys.__stdout__
    
    result = captured_output.getvalue().strip()
    
    print(f"输入: {test_input.replace(chr(10), ' | ')}")
    print(f"期望: {expected_output}")
    print(f"实际: {result}")
    print(f"结果: {'✓ 通过' if result == expected_output else '✗ 失败'}")
    print()

def test_multiple_samples():
    """测试多个样本的情况"""
    print("=== 测试2: 多个样本 ===")
    
    test_input = """3 2
0.1 0.2
-0.3 0.4
0.5 -0.6
1.0 2.0
3.0 4.0
5.0 6.0"""
    
    expected_output = """1.10 2.20
2.70 4.40
5.50 5.40"""
    
    sys.stdin = io.StringIO(test_input)
    captured_output = io.StringIO()
    sys.stdout = captured_output
    
    from generator_gan import simple_generator
    simple_generator()
    
    sys.stdin = sys.__stdin__
    sys.stdout = sys.__stdout__
    
    result = captured_output.getvalue().strip()
    
    print(f"输入数据: 3个样本，2个特征")
    print("期望输出:")
    print(expected_output)
    print("实际输出:")
    print(result)
    print(f"结果: {'✓ 通过' if result == expected_output else '✗ 失败'}")
    print()

def test_negative_values():
    """测试负值情况"""
    print("=== 测试3: 负值处理 ===")
    
    test_input = """2 3
-1.0 -2.0 -3.0
1.5 -0.5 2.5
-0.5 1.0 2.0
-1.0 -1.5 0.5"""
    
    sys.stdin = io.StringIO(test_input)
    captured_output = io.StringIO()
    sys.stdout = captured_output
    
    from generator_gan import simple_generator
    simple_generator()
    
    sys.stdin = sys.__stdin__
    sys.stdout = sys.__stdout__
    
    result = captured_output.getvalue().strip()
    
    print("输入数据: 包含负值")
    print("实际输出:")
    print(result)
    
    # 手动验证
    noise = np.array([[-1.0, -2.0, -3.0], [1.5, -0.5, 2.5]])
    real = np.array([[-0.5, 1.0, 2.0], [-1.0, -1.5, 0.5]])
    expected = real + noise
    manual_result = '\n'.join([' '.join([f"{x:.2f}" for x in row]) for row in expected])
    
    print("手动计算:")
    print(manual_result)
    print(f"结果: {'✓ 通过' if result == manual_result else '✗ 失败'}")
    print()

def test_advanced_generator():
    """测试高级生成器（带统计信息）"""
    print("=== 测试4: 高级生成器 ===")
    
    test_input = """2 3
0.1 0.2 0.3
-0.1 -0.2 -0.3
1.0 2.0 3.0
4.0 5.0 6.0"""
    
    sys.stdin = io.StringIO(test_input)
    captured_output = io.StringIO()
    captured_error = io.StringIO()
    sys.stdout = captured_output
    sys.stderr = captured_error
    
    from advanced_generator import advanced_generator_with_stats
    advanced_generator_with_stats()
    
    sys.stdin = sys.__stdin__
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    
    result = captured_output.getvalue().strip()
    error_output = captured_error.getvalue()
    
    print("标准输出:")
    print(result)
    print("统计信息:")
    print(error_output)
    print()

def run_all_tests():
    """运行所有测试"""
    print("开始运行GAN生成器测试套件\n")
    
    try:
        test_single_sample()
        test_multiple_samples()
        test_negative_values()
        test_advanced_generator()
        
        print("=== 测试完成 ===")
        print("所有测试已执行完毕")
        
    except Exception as e:
        print(f"测试过程中出现错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    run_all_tests() 